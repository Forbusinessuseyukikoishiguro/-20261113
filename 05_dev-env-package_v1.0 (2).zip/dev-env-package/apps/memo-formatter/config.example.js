/* config.js — 練習用の設定（APIキー不要）。模倣サーバー（mock-ai-server.js）を指す */
window.APP_CONFIG = Object.freeze({
  endpoint: "http://localhost:8789",   // 模倣サーバーの場所
  apiKey: "",                          // 模倣サーバーは不要。本物を使うときだけ設定する
  timeoutMs: 15000,                    // 応答の上限（ミリ秒）
});
