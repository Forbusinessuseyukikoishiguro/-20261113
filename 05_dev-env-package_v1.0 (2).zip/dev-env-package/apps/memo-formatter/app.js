/* app.js — 画面の制御。整形そのものは模倣サーバーが行い、ここでは送受信と表示だけを行う */
(function () {
  "use strict";

  // 設定が無い場合の既定値（練習用：模倣サーバーの場所）。本物の設定は config.js で上書きする
  const cfg = Object.assign({ endpoint: "http://localhost:8789", timeoutMs: 15000 }, window.APP_CONFIG || {});
  const $ = (id) => document.getElementById(id);
  const ui = { memo: $("memo"), run: $("run"), count: $("count"), result: $("result"), copy: $("copy"), status: $("status") };

  // 結果を、人が読む形の文字にする（textContent で表示するので、HTMLとしては解釈されない）
  function renderMinutes(m) {
    const out = [];
    out.push(`【件名】${m.title || "（件名なし）"}`);
    out.push("");
    out.push("■ 決定事項");
    if (m.decisions.length === 0) out.push("・（なし）");
    m.decisions.forEach((d) => out.push(`・${d}`));
    out.push("");
    out.push("■ ToDo");
    if (m.todos.length === 0) out.push("・（なし）");
    m.todos.forEach((t) => out.push(`・${t.owner}（期限：${t.due}）：${t.task}`));
    out.push("");
    out.push("■ メモ");
    if (m.notes.length === 0) out.push("・（なし）");
    m.notes.forEach((n) => out.push(`・${n}`));
    return out.join("\n");
  }

  function setStatus(text, isError) {
    ui.status.textContent = text;
    ui.status.classList.toggle("error", Boolean(isError));
  }

  // 送信：タイムアウトつき。失敗の種類ごとに、分かりやすい文言にする
  async function format() {
    const text = ui.memo.value;
    if (text.trim() === "") { setStatus("メモが空です。内容を入力してください。", true); return; }

    ui.run.disabled = true;
    setStatus("整形しています…");
    const ctl = new AbortController();
    const timer = setTimeout(() => ctl.abort(), cfg.timeoutMs || 15000);
    try {
      const headers = { "Content-Type": "application/json" };
      if (cfg.apiKey) headers.Authorization = `Bearer ${cfg.apiKey}`;
      const res = await fetch(`${cfg.endpoint}/v1/format`, {
        method: "POST", headers, body: JSON.stringify({ text }), signal: ctl.signal,
      });
      if (!res.ok) {
        throw Object.assign(new Error(`HTTP ${res.status}`), { status: res.status });
      }
      const data = await res.json();
      ui.result.textContent = renderMinutes(data);
      ui.copy.disabled = false;
      setStatus("整形が終わりました。");
    } catch (e) {
      ui.result.textContent = "整形できませんでした。";
      if (e.name === "AbortError") setStatus("時間内に応答がありませんでした。もう一度お試しください。", true);
      else if (e.name === "TypeError") setStatus("サーバーに接続できません。模倣サーバーが起動しているか確認してください。", true);
      else if (e.status) setStatus(`サーバーでエラーが起きました（${e.status}）。`, true);
      else setStatus("予期しないエラーが起きました。", true);
    } finally {
      clearTimeout(timer);
      ui.run.disabled = false;
    }
  }

  async function copyResult() {
    try {
      await navigator.clipboard.writeText(ui.result.textContent);
      setStatus("コピーしました。");
    } catch {
      setStatus("コピーできませんでした。結果を選択して手動でコピーしてください。", true);
    }
  }

  ui.memo.addEventListener("input", () => {
    ui.count.textContent = `${ui.memo.value.length} 文字`;
  });
  ui.run.addEventListener("click", format);
  ui.copy.addEventListener("click", copyResult);
})();
