/* ============================================================================
 * mock-ai-server.js — 会議メモ整形ツールの模倣サーバー（APIキー不要・課金なし）
 * ----------------------------------------------------------------------------
 * 起動：node mock-ai-server.js        （既定：localhost:8789）
 * 役割：本物のAIサービスの代わりに、同じ形式の応答を返す。
 *       中身は「決まった書き方のルール」で整形するだけ（AIではない）。
 * 応答の形：{ title, decisions:[], todos:[{owner,due,task}], notes:[] }
 * 書き方のルール：
 *   1行目（空行を除く）：件名。「件名:」で始めてもよい
 *   「決定:」で始まる行  → 決定事項
 *   「ToDo:」で始まる行  → ToDo。「担当=名前 期限=日付 内容=文」の形で書く（順不同、無い項目は「未定」）
 *   その他              → メモ
 * ============================================================================ */
"use strict";
const http = require("http");

const PORT = Number(process.env.PORT || 8789);
const DELAY_MS = Number(process.env.DELAY_MS || 300);   // 応答の待ち時間（本物らしく見せる。0 で即時）

// 整形のルール（テストからも使う）
function parseMemo(text) {
  const lines = String(text || "").split(/\r?\n/).map((s) => s.trim()).filter((s) => s !== "");
  const out = { title: "", decisions: [], todos: [], notes: [] };
  if (lines.length === 0) return out;

  out.title = lines[0].replace(/^件名[:：]\s*/, "");
  for (const line of lines.slice(1)) {
    if (/^決定[:：]/.test(line)) {
      out.decisions.push(line.replace(/^決定[:：]\s*/, ""));
    } else if (/^ToDo[:：]/i.test(line)) {
      const body = line.replace(/^ToDo[:：]\s*/i, "");
      const pick = (key) => {
        const m = body.match(new RegExp(key + "=(\\S+)"));
        return m ? m[1] : null;
      };
      // 内容は「内容=」以降をすべて使う（空白を含めてよい）
      const content = body.match(/内容=(.*)$/);
      out.todos.push({
        owner: pick("担当") || "未定",
        due: pick("期限") || "未定",
        task: content ? content[1].trim() : "未定",
      });
    } else {
      out.notes.push(line);
    }
  }
  return out;
}

function send(res, code, obj) {
  const body = JSON.stringify(obj);
  res.writeHead(code, {
    "Content-Type": "application/json; charset=utf-8",
    "Content-Length": Buffer.byteLength(body),
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type, Authorization",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
  });
  res.end(body);
}

const server = http.createServer((req, res) => {
  if (req.method === "OPTIONS") return send(res, 204, {});
  if (req.method !== "POST" || req.url !== "/v1/format") {
    return send(res, 404, { error: "not found" });
  }
  let raw = "";
  req.on("data", (c) => { raw += c; if (raw.length > 100000) req.destroy(); });
  req.on("end", () => {
    let data;
    try { data = JSON.parse(raw || "{}"); } catch { return send(res, 400, { error: "JSON が不正です" }); }
    if (typeof data.text !== "string" || data.text.trim() === "") {
      return send(res, 400, { error: "text が空です" });
    }
    setTimeout(() => send(res, 200, parseMemo(data.text)), DELAY_MS);
  });
});

module.exports = { parseMemo, server };

if (require.main === module) {
  server.listen(PORT, () => console.log(`mock AI server on http://localhost:${PORT}/v1/format`));
}
