#!/usr/bin/env python3
"""
e2e_memo.py — 会議メモ整形ツールの画面試験（実ブラウザ・模倣サーバー使用）
実行：python3 apps/memo-formatter/test/e2e_memo.py   （ルートのフォルダから）
確認：正常系（整形・分類・コピー）、空入力、サーバー停止時の案内、サーバーの誤り（404）
"""
import http.server, os, socket, subprocess, sys, threading, time, urllib.request, functools
from playwright.sync_api import sync_playwright

HERE = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SCRIPTS = os.path.abspath(os.path.join(HERE, "..", "..", "scripts"))
sys.path.insert(0, SCRIPTS)
from browser_launch import launch_browser  # noqa: E402

WEB_PORT, AI_PORT = 8200, 8789
# 練習用の設定（config.js）が無ければ、雛形から作る（config.js は Git に入らない）
import shutil
_cfg = os.path.join(HERE, "config.js")
if not os.path.exists(_cfg):
    shutil.copy(os.path.join(HERE, "config.example.js"), _cfg)
results = []

def check(name, ok, detail=""):
    results.append((name, ok))
    print(f"[{'合' if ok else '否'}] {name} {'' if ok else detail}", flush=True)

def wait_port(port, want, timeout=10):
    end = time.time() + timeout
    while time.time() < end:
        with socket.socket() as s:
            s.settimeout(0.3)
            if (s.connect_ex(("127.0.0.1", port)) == 0) == want:
                return True
        time.sleep(0.2)
    return False

class Quiet(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *a):
        pass

def main():
    web = http.server.ThreadingHTTPServer(("127.0.0.1", WEB_PORT), functools.partial(Quiet, directory=HERE))
    threading.Thread(target=web.serve_forever, daemon=True).start()
    ai = subprocess.Popen(["node", os.path.join(HERE, "mock-ai-server.js")], env=dict(os.environ, PORT=str(AI_PORT), DELAY_MS="50"),
                          stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    try:
        wait_port(AI_PORT, True)
        with sync_playwright() as p:
            b = launch_browser(p)
            pg = b.new_page()
            errors = []
            pg.on("pageerror", lambda e: errors.append(str(e)))
            pg.goto(f"http://localhost:{WEB_PORT}/index.html")
            memo = ("件名: 週次定例\n決定: 来月から会議を30分に短縮\n"
                    "ToDo: 担当=山田 期限=2026-11-30 内容=資料を作る\n参加者は5名")
            pg.fill("#memo", memo)
            pg.click("#run")
            pg.wait_for_function("document.getElementById('status').textContent.includes('整形が終わりました')", timeout=15000)
            out = pg.inner_text("#result")
            check("整形できる（件名）", "【件名】週次定例" in out, out[:80])
            check("決定事項に分類される", "来月から会議を30分に短縮" in out.split("■ ToDo")[0], out)
            check("ToDo に担当と期限が出る", "山田（期限：2026-11-30）：資料を作る" in out, out)
            check("メモに分類される", "参加者は5名" in out.split("■ メモ")[-1], out)
            check("コピーが押せる", pg.is_enabled("#copy"))

            pg.fill("#memo", "   ")
            pg.click("#run")
            check("空入力は案内する", "メモが空です" in pg.inner_text("#status"), pg.inner_text("#status"))

            # サーバーの誤り：通信の段階で、応答を 404 に差し替える（設定の書き換えは、再読み込みで戻るため使わない）
            cors = {"Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "Content-Type, Authorization"}
            pg.route("**/v1/format", lambda r: r.fulfill(status=404, body='{"error":"not found"}',
                                                          headers=dict(cors, **{"Content-Type": "application/json"})))
            pg.fill("#memo", "件名: テスト"); pg.click("#run")
            pg.wait_for_function("document.getElementById('status').textContent.includes('エラーが起きました')", timeout=15000)
            check("サーバーの誤り（404）は、エラーとして案内する", "（404）" in pg.inner_text("#status"), pg.inner_text("#status"))
            pg.unroute("**/v1/format")

            # サーバー停止：接続できないことを案内する
            ai.terminate(); ai.wait(timeout=5); wait_port(AI_PORT, False)
            pg.fill("#memo", "件名: テスト"); pg.click("#run")
            pg.wait_for_function("document.getElementById('status').textContent.includes('接続できません')", timeout=15000)
            check("サーバー停止時は、接続できないと案内する", True)
            b.close()
        check("ページに未処理の例外がない", not errors, "; ".join(errors))
    finally:
        if ai.poll() is None:
            ai.terminate()
        web.shutdown()
    fails = [n for n, ok in results if not ok]
    print(f"\n== 結果：合格 {len(results) - len(fails)} / {len(results)} ==")
    sys.exit(1 if fails else 0)

if __name__ == "__main__":
    main()
