/* parse.test.js — 整形ルール（parseMemo）の単体試験。実行：node --test test/parse.test.js */
const test = require("node:test");
const assert = require("node:assert/strict");
const { parseMemo } = require("../mock-ai-server.js");

test("件名は1行目。「件名:」は取り除く", () => {
  assert.equal(parseMemo("件名: 週次定例\n").title, "週次定例");
  assert.equal(parseMemo("週次定例\n").title, "週次定例");
});

test("決定・ToDo・メモに分類される", () => {
  const r = parseMemo("件名: A\n決定: 会議を30分に\nToDo: 担当=山田 期限=2026-11-30 内容=資料を作る\n参加者は5名");
  assert.deepEqual(r.decisions, ["会議を30分に"]);
  assert.deepEqual(r.todos, [{ owner: "山田", due: "2026-11-30", task: "資料を作る" }]);
  assert.deepEqual(r.notes, ["参加者は5名"]);
});

test("ToDo の項目が無いときは「未定」", () => {
  const r = parseMemo("件名: A\nToDo: 内容=確認する");
  assert.deepEqual(r.todos, [{ owner: "未定", due: "未定", task: "確認する" }]);
});

test("ToDo の内容は空白を含んでよい", () => {
  const r = parseMemo("件名: A\nToDo: 担当=佐藤 内容=資料 を 作る");
  assert.equal(r.todos[0].task, "資料 を 作る");
});

test("空のメモは、空の結果を返す（例外にならない）", () => {
  assert.deepEqual(parseMemo(""), { title: "", decisions: [], todos: [], notes: [] });
  assert.deepEqual(parseMemo("   \n  "), { title: "", decisions: [], todos: [], notes: [] });
});

test("全角コロンでも分類される", () => {
  const r = parseMemo("件名： A\n決定： 承認\n");
  assert.equal(r.title, "A");
  assert.deepEqual(r.decisions, ["承認"]);
});
