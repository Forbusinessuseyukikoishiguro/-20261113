#!/usr/bin/env python3
"""
browser_launch.py — ブラウザ起動の共通処理と、起動できない原因の切り分け

使い方:
  python scripts/check_browser.py        ← 起動できるかを確かめ、直し方を表示する
  環境変数 PW_CHANNEL=msedge（または chrome）を付けると、PC に入っている Edge / Chrome で起動する

起動の順番:
  1. 既定の Chromium（playwright install で入れたもの）
  2. 失敗したら、PW_CHANNEL で指定したブラウザ（未指定なら msedge を試す）
"""
import os
import sys


def launch_browser(p, headless=True):
    """Playwright の Chromium を起動する。失敗時は、直し方つきの例外にする。"""
    channel = os.environ.get("PW_CHANNEL", "").strip() or None
    try:
        return p.chromium.launch(headless=headless, channel=channel)
    except Exception as first:
        if channel is None:
            # 既定の Chromium が無い場合は、PC の Edge で再試行する
            try:
                return p.chromium.launch(headless=headless, channel="msedge")
            except Exception:
                pass
        msg = str(first).splitlines()[0] if str(first) else "（詳細なし）"
        raise RuntimeError(
            "ブラウザを起動できませんでした。\n"
            f"  原因の候補：{msg}\n"
            "  直し方（上から順に試す）：\n"
            "   1) python -m playwright install chromium   （Chromium を入れる）\n"
            "   2) Windows なら py -m playwright install chromium（python が複数ある場合）\n"
            "   3) 社内の通信制限で入らない場合：PW_CHANNEL=msedge を設定して Edge で起動する\n"
            "      PowerShell:  $env:PW_CHANNEL=\"msedge\"\n"
            "   4) Linux でライブラリ不足と出る場合：python -m playwright install --with-deps chromium\n"
            "   5) python scripts/check_browser.py で、どこで止まるかを確かめる"
        ) from first
