#!/usr/bin/env python3
"""
check_browser.py — ブラウザ起動の事前確認（どこで失敗しているかを順に表示する）
実行: python scripts/check_browser.py
"""
import platform
import sys

def step(ok, text):
    print(("[OK]  " if ok else "[NG]  ") + text)
    return ok

print(f"Python {sys.version.split()[0]} / {platform.system()}")
ok = step(sys.version_info >= (3, 9), "Python 3.9 以上")
try:
    import playwright  # noqa
    ok = step(True, "playwright が入っている") and ok
except ImportError:
    ok = step(False, "playwright が入っていない → pip install playwright（Windows は py -m pip install playwright）") and ok
    sys.exit(1)

from playwright.sync_api import sync_playwright
sys.path.insert(0, __import__("os").path.dirname(__file__))
from browser_launch import launch_browser

try:
    with sync_playwright() as p:
        b = launch_browser(p)
        ok = step(True, f"ブラウザを起動できた（{b.version}）") and ok
        pg = b.new_page()
        pg.set_content("<p>ok</p>")
        ok = step(pg.inner_text("p") == "ok", "ページを描画できた") and ok
        b.close()
except Exception as e:
    step(False, "ブラウザを起動できなかった")
    print(str(e))
    ok = False

print("\n結果:", "起動できています。試験を実行できます。" if ok else "上の [NG] を直してから、もう一度実行してください。")
sys.exit(0 if ok else 1)
