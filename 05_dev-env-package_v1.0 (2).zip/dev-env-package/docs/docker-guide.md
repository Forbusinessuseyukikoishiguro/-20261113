# Docker での試験手順（初回・次回）

対象：Windows（Docker Desktop）、Mac、Linux。ブラウザ（Chromium）を含む試験環境を、1つのイメージにまとめて実行します。

## 1. 初回：Docker を用意する
1. Docker Desktop を入れる（Windows は WSL 2 を使う設定で入れる）。
2. Docker Desktop を起動し、タスクトレイのクジラのアイコンが「Running」になるまで待つ。
3. 確認：`docker version` を実行し、Client と Server の両方が表示されること。

## 2. 初回：イメージを作る
プロジェクトのフォルダで実行します（Docker Hub に接続できる環境が必要です）。

```
docker build -t speech-test:1.4.1 .
```

- 初回は、基礎イメージ（node:22-bookworm）とブラウザの取得で、10〜20分かかることがあります。
- 2回目以降は、変更した部分だけを作り直すので速くなります。

## 3. ブラウザが起動するかを確かめる（最重要）
```
docker run --rm --shm-size=1g speech-test:1.4.1 python scripts/check_browser.py
```

- 最後の行が「起動できています。試験を実行できます。」なら成功です。
- `--shm-size=1g` は、ブラウザが共有メモリ不足で落ちるのを防ぐためのものです（既定は 64MB）。

## 4. 全体の試験を実行する
```
docker run --rm --shm-size=1g speech-test:1.4.1 sh -c "npm run verify && npm run e2e"
```

- verify：ビルド、単体試験（23件）、秘密情報の検査
- e2e：ブラウザでの画面試験（13件）

## 5. 結果をWindowsに残す（PowerShell）
```
docker run --rm --shm-size=1g -v "${PWD}\test\results:/app/test/results" speech-test:1.4.1 sh -c "npm run verify && npm run e2e && node scripts/collect-evidence.js --e2e"
```

- 結果は `test\results` に保存されます。
- 注意：`${PWD}` は PowerShell の書き方です（cmd では `%cd%`）。

## 6. 次回以降
```
docker build -t speech-test:1.4.1 .          # 変更があったときだけ
docker run --rm --shm-size=1g speech-test:1.4.1 python scripts/check_browser.py
```

## 7. 困ったとき
| 症状 | 原因 | 対処 |
|---|---|---|
| `docker build` で Docker Hub に接続できない | ネットワーク制限、プロキシ | 社内の情報システムに Docker Hub への接続可否を確認する |
| `Cannot connect to the Docker daemon` | Docker Desktop が起動していない | Docker Desktop を起動し、Running を待つ |
| ブラウザが起動しない（Target closed） | 共有メモリ不足、または古いイメージ | `--shm-size=1g` を付ける。イメージを作り直す（`docker build --no-cache`） |
| `playwright install` が CDN に接続できない | ブラウザの取得先に接続できない | 社内の通信を確認。代わりに `PW_CHANNEL=msedge` を設定して Edge を使う |
| Windows で改行の警告が出る | CRLF と LF の違い | 動作には影響しない（.gitattributes で管理） |

## 8. この手順書の検証状況（正直な記録）
- 検証日：2026-11-12（作業環境）。
- 確認できたこと：Docker 29.1.3 のデーモンで、`check_browser.py` が起動・描画まで成功、`npm run verify`（単体23件・秘密検査）が成功、`npm run e2e`（画面13件）が 13/13 で成功。
- この環境での差異：Docker Hub に接続できなかったため、基礎イメージを Ubuntu 24.04 から作り、Node.js 22 を入れて代用した（本番の node:22-bookworm ではない）。ブラウザは事前に入っていたものをイメージに含めた。Playwright は 1.63.0 に固定した。
- 未確認：Docker Hub の node:22-bookworm を使った標準のビルド、Windows の Docker Desktop 上での実行、Mac での実行。上の手順を、実際の環境で必ず一度実行して確かめてください。
