# HTML・CSS・JavaScript ツールの開発環境（Docker・Ubuntu・WSL・Windows）

対象：HTML・CSS・JavaScript でツールを作る人。APIキーは使わず、模倣サーバー（モック）で開発・練習する。

## 0. 全体像
```
あなたのPC（Windows / Ubuntu / Mac）
 ├─ エディタ（VS Code）… ファイルを編集する（ホストの普通のフォルダ）
 ├─ Docker（任意だが推奨）… 開発環境を、同じ条件で再現する
 │    └─ web-dev コンテナ：Node.js 22 / Python 3 / Playwright / Chromium
 │          ├─ 模倣サーバー（8789：AI用、8787：Azure用）
 │          └─ 画面の配信（8000：HTML を http:// で開けるようにする）
 └─ ブラウザ（Chrome / Edge）… http://localhost:8000/... を開く
```
ポイント：コードは**ホスト（あなたのフォルダ）に置き**、コンテナにはフォルダを割り当てる（`-v`）。だから、VS Code で直すと、すぐにコンテナでも動く。

---

## 1. Windows（推奨の入口：Docker Desktop＋WSL 2）
1. **WSL 2 を入れる**（PowerShell を管理者で開く）
   ```powershell
   wsl --install -d Ubuntu
   ```
   再起動を求められたら再起動する。初回起動で Ubuntu のユーザー名とパスワードを決める。
2. **Docker Desktop を入れる**（https://www.docker.com/）。インストール時に「Use WSL 2」を有効にする。
3. Docker Desktop の Settings → Resources → WSL Integration で、Ubuntu を有効にする。
4. **VS Code を入れる**。拡張機能「WSL」「Dev Containers」「Docker」を入れる（任意）。
5. 確認（PowerShell）
   ```powershell
   docker version
   ```
   Client と Server の両方が出れば成功。

## 2. WSL（Ubuntu）の中で作業する場合
プロジェクトは **WSL のファイルシステム（/home/ユーザー名/）に置く**。Windows 側の `/mnt/c/...` に置くと、ファイルの読み書きが遅くなり、改行の問題も起きやすい。

```bash
cd ~
git clone <リポジトリのURL> web-tools     # または zip を展開する
cd web-tools
docker build -f docker/dev/Dockerfile -t web-dev:1.0 .
```

## 3. Ubuntu（ネイティブ）の場合
```bash
sudo apt-get update && sudo apt-get install -y docker.io git
sudo usermod -aG docker $USER      # 一度ログアウトして入り直す
docker version
cd ~/web-tools
docker build -f docker/dev/Dockerfile -t web-dev:1.0 .
```

## 4. 開発用コンテナを起動する（Ubuntu・WSL・Mac 共通）
```bash
docker run --rm -it --shm-size=1g \
  -v "$PWD:/work" \
  -p 8000:8000 -p 8789:8789 \
  web-dev:1.0 bash
```
- `-v "$PWD:/work"`：今いるフォルダ（プロジェクト）をコンテナの /work に割り当てる
- `-p 8000:8000`：HTML の配信用。`-p 8789:8789`：模倣サーバー用
- `--shm-size=1g`：ブラウザを使う試験で落ちないようにする

Windows（PowerShell）では、`$PWD` を `${PWD}` に書く：
```powershell
docker run --rm -it --shm-size=1g -v "${PWD}:/work" -p 8000:8000 -p 8789:8789 web-dev:1.0 bash
```

## 5. 模倣サーバーを起動する（コンテナの中で）
```bash
# 別の端末（または & を付けて裏で）
node apps/memo-formatter/mock-ai-server.js        # 8789 で待ち受け
python3 -m http.server 8000 --bind 0.0.0.0        # 画面の配信（別の端末）
```
ホスト（あなたのPC）のブラウザで、次を開く：
**http://localhost:8000/apps/memo-formatter/index.html**

動作の確認（ホストの端末で）：
```bash
curl -s -X POST http://localhost:8789/v1/format \
  -H "Content-Type: application/json" \
  -d '{"text":"件名: テスト\n決定: 承認"}'
```
Windows（PowerShell）では：
```powershell
Invoke-RestMethod -Method Post -Uri http://localhost:8789/v1/format -ContentType "application/json" -Body '{"text":"件名: テスト"}'
```

## 6. ネイティブ（Docker なし）で動かす場合（Windows・Ubuntu・Mac）
Node.js 22 を入れる（https://nodejs.org/。または nvm）。

```powershell
# Windows（PowerShell）
node -v                                     # v22 系なら可
node apps\memo-formatter\mock-ai-server.js
# 別の PowerShell で
python -m http.server 8000
```
```bash
# Ubuntu / WSL / Mac
node -v
node apps/memo-formatter/mock-ai-server.js
python3 -m http.server 8000
```

## 7. 試験を実行する
| 目的 | コマンド（コンテナ内 or プロジェクトのフォルダで） |
|---|---|
| ブラウザが起動するか | `python3 scripts/check_browser.py` |
| 整形ルールの単体試験 | `node --test apps/memo-formatter/test/parse.test.js` |
| 画面の試験（模倣サーバーを自動起動） | `python3 apps/memo-formatter/test/e2e_memo.py` |

## 8. 模倣サーバーの設定
| 環境変数 | 既定 | 意味 |
|---|---|---|
| PORT | 8789 | 待ち受けポート |
| DELAY_MS | 300 | 応答を遅らせるミリ秒（0 で即時） |

画面側の設定は `apps/memo-formatter/config.js`（endpoint・timeoutMs）。練習用には `config.example.js` を `config.js` という名前でコピーして使う（無くても、既定値で動く）。APIキーは空でよい。

## 9. よくあるつまずき
| 症状 | 原因 | 対処 |
|---|---|---|
| `docker: command not found` | Docker 未導入 | §1 または §3 |
| `Cannot connect to the Docker daemon` | Docker Desktop 未起動 | Docker Desktop を起動して Running を待つ |
| 画面が「接続できません」 | 模倣サーバーが起動していない | `node apps/memo-formatter/mock-ai-server.js` を起動 |
| `Address already in use` | ポートが使用中 | 前の起動を止める。または `PORT=8790` で変える |
| ブラウザで index.html を直接開いても動かない | file:// の制限 | 必ず `http://localhost:8000/...` で開く |
| WSL で遅い | プロジェクトが /mnt/c にある | WSL の中（~/）に置く |
| 改行の警告 | CRLF と LF | 動作には影響しない |

## 10. 検証の状況（正直な記録）
| 環境 | 確認内容 | 結果 |
|---|---|---|
| Docker（web-dev:1.0、Ubuntu 24.04 の基礎イメージで作成） | ブラウザ起動、整形の画面試験 9件、単体試験 6件、模倣サーバーの起動と外からの呼び出し | ✅ |
| Ubuntu（ネイティブ、検証機） | 模倣サーバー、単体試験、画面試験 | ✅ |
| Windows（ネイティブ・PowerShell） | — | ⬜ 未確認（手順のみ） |
| WSL 2 | — | ⬜ 未確認（手順のみ） |
| Mac | — | ⬜ 未確認 |

Docker Hub の標準イメージ（node:22-bookworm）での作成は、この検証では行っていない（docs/docker-guide.md の §8 を参照）。
