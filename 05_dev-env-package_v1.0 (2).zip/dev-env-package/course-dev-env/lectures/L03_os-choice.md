# L03 Windows・WSL・Ubuntu の選び方（約5分）

## 目標
自分の環境に合う入口を選べる。

## 台本
環境は3つから選びます。
- **Windows（Docker Desktop と WSL 2）**：一番手軽。Windows の操作のまま使える
- **WSL 2 の Ubuntu**：Linux の操作を覚えたい人向け。本番に近い
- **Ubuntu（ネイティブ）**：Linux を普段使う人向け

迷ったら、Windows で Docker Desktop を入れ、WSL 2 の Ubuntu の中でプロジェクトを作るのがおすすめです。

注意があります。プロジェクトは、WSL の中（/home の下）に置きます。Windows 側のフォルダに置くと、遅くなったり、改行の問題が起きたりします。

## デモ
- 手順書の §1〜§3 を見せる

## 要点
- Windows は Docker Desktop、WSL の中にプロジェクトを置く
