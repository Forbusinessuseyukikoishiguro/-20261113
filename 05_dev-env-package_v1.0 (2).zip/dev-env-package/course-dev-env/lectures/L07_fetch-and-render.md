# L07 サーバーへ送って、結果を表示する（約7分）

## 目標
fetch で送り、受け取った結果を画面に表示できる。

## 台本
ボタンが押されたら、メモをサーバーへ送ります。JavaScript では fetch を使います。

    const res = await fetch(`${cfg.endpoint}/v1/format`, {
      method: "POST",
      headers,
      body: JSON.stringify({ text }),
    });

送るのは JSON の文字です。受け取ったら、res.json() で中身を取り出します。

表示のとき、textContent を使います。innerHTML を使うと、メモの中の文字が HTML として動いてしまうからです。これは、安全のための大事な約束です。

## デモ
- app.js の fetch と textContent の部分を見せる
- メモに「<b>太字</b>」と書き、そのまま文字で出ることを見せる

## 要点
- 送るのは JSON、表示は textContent
