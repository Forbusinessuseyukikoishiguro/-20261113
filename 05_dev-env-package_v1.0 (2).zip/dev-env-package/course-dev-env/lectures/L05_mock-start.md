# L05 模倣サーバーを起動して確かめる（約6分）

## 目標
模倣サーバーを起動し、外から応答を確かめられる。

## 台本
コンテナの中で、模倣サーバーを起動します。
    node apps/memo-formatter/mock-ai-server.js

別の端末で、画面を配信します。
    python3 -m http.server 8000 --bind 0.0.0.0

あなたの PC から、次の命令で確かめます。
    curl -s -X POST http://localhost:8789/v1/format -H "Content-Type: application/json" -d '{"text":"件名: テスト"}'

title の欄に「テスト」と返ってくれば成功です。

Windows の PowerShell では、Invoke-RestMethod を使います。

## デモ
- 起動、curl、画面の表示を順に見せる（画面の URL は http://localhost:8000/apps/memo-formatter/index.html）

## 要点
- 模倣サーバーは、ポート 8789
- 画面は、必ず http:// で開く
