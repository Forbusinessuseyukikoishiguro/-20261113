# L04 Docker で開発環境を作る（約6分）

## 目標
開発用のイメージを作り、コンテナを起動できる。

## 台本
開発用のイメージは、Dockerfile というファイルで作ります。中身は、Node.js、Python、ブラウザを動かすための道具です。

作るコマンドは1つです。
    docker build -f docker/dev/Dockerfile -t web-dev:1.0 .

起動するコマンドも1つです。
    docker run --rm -it --shm-size=1g -v "$PWD:/work" -p 8000:8000 -p 8789:8789 web-dev:1.0 bash

- -v は、今のフォルダをコンテナに見せる
- -p は、コンテナの中の port をあなたの PC に開く
- --shm-size は、ブラウザが落ちないための設定

## デモ
- build、run を順に実行し、コンテナの中で「ls」を見せる

## 要点
- イメージは作り、コンテナは起動する
- コードはホストに置き、-v で見せる
