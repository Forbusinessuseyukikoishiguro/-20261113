#!/usr/bin/env python3
"""現状分析（読み取り専用）。ファイルを一切変更しない。
使い方: python3 analyze.py <対象フォルダ> [--out analysis] [--max-depth 3]
出力: <out>.md（人が読む） <out>.json（機械用）
"""
import argparse, hashlib, json, os, re, sys, subprocess
from collections import Counter, defaultdict
from datetime import datetime

SKIP = {'.git', 'node_modules', '__pycache__', '.venv', 'venv', '.idea', '.vscode', 'dist', 'build', '.next', '.cache'}
BAD_NAME = re.compile(r'[ 　()（）\[\]【】&#%!?？！]')
VERSION_LIKE = re.compile(r'(_?v\d+|_?ver\d+|_?final|_?最終|_?修正|_?コピー|copy|\(\d+\)|_old|_bak|_new|\d{8})', re.I)

def sha1(p, limit=50 * 1024 * 1024):
    try:
        if os.path.getsize(p) > limit:
            return None
        h = hashlib.sha1()
        with open(p, 'rb') as f:
            for b in iter(lambda: f.read(1 << 20), b''):
                h.update(b)
        return h.hexdigest()
    except OSError:
        return None

def tree(root, max_depth):
    lines = []
    def walk(d, prefix, depth):
        try:
            items = sorted(os.listdir(d), key=lambda x: (not os.path.isdir(os.path.join(d, x)), x.lower()))
        except OSError:
            return
        items = [i for i in items if i not in SKIP]
        for i, name in enumerate(items):
            p = os.path.join(d, name)
            last = i == len(items) - 1
            lines.append(f"{prefix}{'└── ' if last else '├── '}{name}{'/' if os.path.isdir(p) else ''}")
            if os.path.isdir(p) and depth < max_depth:
                walk(p, prefix + ('    ' if last else '│   '), depth + 1)
    lines.append(os.path.basename(os.path.abspath(root)) + '/')
    walk(root, '', 1)
    return lines

def git_info(root):
    try:
        top = subprocess.run(['git', '-C', root, 'rev-parse', '--show-toplevel'], capture_output=True, text=True, timeout=10)
        if top.returncode != 0:
            return {'is_git': False}
        st = subprocess.run(['git', '-C', root, 'status', '--porcelain'], capture_output=True, text=True, timeout=30)
        br = subprocess.run(['git', '-C', root, 'branch', '--show-current'], capture_output=True, text=True, timeout=10)
        return {'is_git': True, 'toplevel': top.stdout.strip(), 'branch': br.stdout.strip(),
                'uncommitted': len([l for l in st.stdout.splitlines() if l.strip()])}
    except Exception:
        return {'is_git': False}

def easy_summary(root_files, dups, ver, bad, empty_dirs, deep, readme):
    tips = []
    if root_files >= 10:
        tips.append(f'- 📂 いちばん上の階層にファイルが {root_files} 個あります。机の上に書類が出しっぱなしの状態です。引き出し（フォルダ）に分けると探しやすくなります。')
    if dups:
        tips.append(f'- 👯 中身がまったく同じファイルが {len(dups)} 組あります。どれが本物か迷う原因になります。')
    if ver:
        tips.append(f'- 🏷️ 名前に「最終」「v2」「コピー」「日付」などが付いたファイルが {len(ver)} 個あります。どれが最新か分かりにくい状態です。')
    if bad:
        tips.append(f'- ✏️ 名前に空白や記号が入ったファイルが {len(bad)} 個あります。システムによっては開けない・送れないことがあります。')
    if empty_dirs:
        tips.append(f'- 🗃️ 中身が空のフォルダが {len(empty_dirs)} 個あります。')
    if deep:
        tips.append(f'- 🪜 フォルダの中のフォルダの中の…と5段以上深い場所が {len(deep)} か所あります。迷子になりやすい状態です。')
    if not readme:
        tips.append('- 📄 「このフォルダは何か」を説明するファイル（README）がありません。初めて見る人が困ります。')
    return tips or ['- ✅ 大きな問題は見つかりませんでした。よく整理されています。']

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('root'); ap.add_argument('--out', default='analysis'); ap.add_argument('--max-depth', type=int, default=3)
    a = ap.parse_args()
    root = os.path.abspath(a.root)
    if not os.path.isdir(root):
        sys.exit(f'フォルダがありません: {root}')
    files, dirs, empty_dirs = [], [], []
    for d, ds, fs in os.walk(root):
        ds[:] = [x for x in ds if x not in SKIP]
        rel = os.path.relpath(d, root)
        depth = 0 if rel == '.' else rel.count(os.sep) + 1
        dirs.append((rel, depth))
        if not ds and not fs and rel != '.':
            empty_dirs.append(rel)
        for f in fs:
            p = os.path.join(d, f)
            try:
                st = os.stat(p)
            except OSError:
                continue
            files.append({'path': os.path.relpath(p, root), 'name': f, 'ext': os.path.splitext(f)[1].lower() or '(なし)',
                          'size': st.st_size, 'mtime': datetime.fromtimestamp(st.st_mtime).strftime('%Y-%m-%d'), 'depth': depth})
    ext = Counter(f['ext'] for f in files)
    by_hash = defaultdict(list)
    for f in files:
        if f['size'] > 0:
            h = sha1(os.path.join(root, f['path']))
            if h:
                by_hash[h].append(f['path'])
    dups = [v for v in by_hash.values() if len(v) > 1]
    bad = [f['path'] for f in files if BAD_NAME.search(f['name'])]
    ver = [f['path'] for f in files if VERSION_LIKE.search(os.path.splitext(f['name'])[0])]
    big = sorted(files, key=lambda x: -x['size'])[:15]
    root_files = [f['path'] for f in files if f['depth'] == 0]
    deep = [r for r, dep in dirs if dep >= 5]
    docs = [f['path'] for f in files if f['ext'] in {'.md', '.docx', '.pdf', '.pptx', '.xlsx', '.txt'}]
    readme = [f['path'] for f in files if f['name'].lower().startswith('readme')]
    g = git_info(root)
    res = {'root': root, 'generated': datetime.now().isoformat(timespec='seconds'), 'file_count': len(files),
           'dir_count': len(dirs), 'total_bytes': sum(f['size'] for f in files), 'max_depth': max((d for _, d in dirs), default=0),
           'ext': ext.most_common(), 'duplicates': dups, 'bad_names': bad, 'version_in_name': ver,
           'empty_dirs': empty_dirs, 'root_files': root_files, 'deep_dirs': deep, 'docs': docs, 'readme': readme,
           'largest': [(f['path'], f['size']) for f in big], 'git': g}
    with open(a.out + '.json', 'w', encoding='utf-8') as fp:
        json.dump(res, fp, ensure_ascii=False, indent=2)
    mb = lambda b: f'{b/1024/1024:.1f}MB'
    L = [f'# 現状分析レポート', '', f'- 対象: `{root}`', f'- 作成: {res["generated"]}（読み取りのみ・変更なし）',
         f'- ファイル数: {len(files)} ／ フォルダ数: {len(dirs)} ／ 合計: {mb(res["total_bytes"])} ／ 最大の深さ: {res["max_depth"]}',
         f'- Git: ' + (f'管理下（ブランチ {g["branch"]}、未コミット {g["uncommitted"]} 件）' if g.get('is_git') else '管理外'), '',
         '## ひとことまとめ（はじめての方へ）', '', *easy_summary(len(root_files), dups, ver, bad, empty_dirs, deep, readme), '',
         '## フォルダ構成（現状）', '', '```', *tree(root, a.max_depth), '```', '',
         '## 種類別ファイル数', '', '| 拡張子 | 件数 |', '|---|---|', *[f'| {e} | {c} |' for e, c in ext.most_common(20)], '',
         '## 気になる点', '',
         f'| 観点 | 件数 | 説明 |', '|---|---|---|',
         f'| 直下に置かれたファイル | {len(root_files)} | 多いと散らかって見える |',
         f'| 重複ファイル（中身が同一） | {sum(len(d) for d in dups)} | {len(dups)} 組 |',
         f'| 名前に版・日付・コピー | {len(ver)} | 版管理を名前で行っている兆候 |',
         f'| 名前に空白・記号・全角括弧 | {len(bad)} | コマンドやURLで扱いにくい |',
         f'| 空フォルダ | {len(empty_dirs)} | |',
         f'| 深さ5以上のフォルダ | {len(deep)} | 迷子になりやすい |',
         f'| README | {len(readme)} | 0 なら入口の説明が無い |', '']
    def sec(title, items, n=30):
        if items:
            L.extend([f'### {title}', '', *[f'- `{i}`' for i in items[:n]], *(['- …ほか %d 件' % (len(items) - n)] if len(items) > n else []), ''])
    sec('直下のファイル', root_files)
    if dups:
        L.extend(['### 重複ファイル', ''])
        for d in dups[:20]:
            L.append('- ' + ' ＝ '.join(f'`{x}`' for x in d))
        L.append('')
    sec('名前に版・日付・コピーを含むもの', ver)
    sec('名前に空白・記号を含むもの', bad)
    sec('空フォルダ', empty_dirs)
    L.extend(['### 大きいファイル', '', *[f'- `{f["path"]}` {mb(f["size"])}' for f in big[:10]], ''])
    with open(a.out + '.md', 'w', encoding='utf-8') as fp:
        fp.write('\n'.join(L))
    print(f'OK: {a.out}.md / {a.out}.json （ファイル {len(files)} 件、変更なし）')

if __name__ == '__main__':
    main()
