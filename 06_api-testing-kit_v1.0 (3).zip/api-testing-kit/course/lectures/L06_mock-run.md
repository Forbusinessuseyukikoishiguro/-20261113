# L06 模倣サーバーを起動し、外から呼ぶ（約7分）

## 目標
模倣サーバーを起動し、curl か PowerShell で応答を確かめられる。

## 台本
ターミナルで、模倣サーバーを起動します。
    python3 server/mock_chat_server.py

別のターミナルで、キーを付けて送ります。
    curl -s -X POST http://127.0.0.1:8790/v1/chat/completions -H "Authorization: Bearer test-key" -H "Content-Type: application/json" -d '{"model":"mock-model","messages":[{"role":"user","content":"こんにちは"}]}'

返事に「【モック】」と入っていれば成功です。キーを外すと、401 が返ります。これは、失敗の確かめにも使えます。

Windows では、Invoke-RestMethod を使います。

## デモ
- 起動、送信、キー無しでの 401 を見せる

## 要点
- キーを付けると 200、外すと 401
