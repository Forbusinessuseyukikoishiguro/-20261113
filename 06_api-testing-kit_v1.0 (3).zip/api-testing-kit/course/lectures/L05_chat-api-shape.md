# L05 チャット形式 API の形（ChatGPT 型で考える）（約8分）

## 目標
送る形と受け取る形を、言葉で説明できる。

## 台本
チャット形式の API は、一般に次の形で使います。ここでは、考え方を学びます。正確な項目は、必ず公式の API リファレンスで確認してください。

送るときは、POST で /v1/chat/completions へ送ります。認証は、ヘッダーの Authorization に Bearer とキーを入れます。本文には、使うモデル名と、messages を入れます。messages は、role と content の組です。role は system、user、assistant のどれかです。

受け取るときは、choices の先頭の message.content に返答の文字が入っています。usage には、使った量が入ります。

模倣サーバーは、この考え方に合わせて作りました。ただし、本物と同じ数え方とは限りません。たとえば usage は、模倣では文字数で近似しています。

## デモ
- server/mock_chat_server.py の応答の作り方（choices と usage）を見せる

## 要点
- 送る：POST・Bearer・model・messages
- 受け取る：choices[0].message.content
- 模倣と本物は、同じとは限らない
