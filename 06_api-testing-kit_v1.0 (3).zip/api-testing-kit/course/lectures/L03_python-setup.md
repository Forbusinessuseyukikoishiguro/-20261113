# L03 Ubuntu・WSL・Windows で Python を用意する（約8分）

## 目標
仮想環境を作り、有効にできる。

## 台本
Python のプロジェクトは、仮想環境の中で動かします。仮想環境は、そのプロジェクト専用の道具箱です。ほかのプロジェクトと混ざらないので、安全です。

Ubuntu と WSL では、こうします。
    python3 -m venv .venv
    source .venv/bin/activate

Windows の PowerShell では、こうします。
    py -m venv .venv
    .\.venv\Scripts\Activate.ps1

有効になると、行の先頭に (.venv) と出ます。実行できないと言われたら、ExecutionPolicy の設定を見ます。

## デモ
- 3つの環境で、venv の作成と有効化を見せる

## 要点
- 仮想環境は、プロジェクトごとに作る
- 有効化は、環境ごとにコマンドが違う
