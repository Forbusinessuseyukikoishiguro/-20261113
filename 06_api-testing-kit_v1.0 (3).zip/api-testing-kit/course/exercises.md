# 演習

## 演習1：応答に「質問の数」を足す（目安 25分）
1. server/mock_chat_server.py の応答の content に、user の発言に「？」が含まれていれば「（質問を含みます）」を付け加える
2. tests/test_api_contract.py に、その規則の試験を1件足す（名前は test_C06_... のように、C の規則に従う）
3. `python3 -m unittest tests/test_api_contract.py` で、18件が通ることを確かめる

## 演習2：入力の検査に「長さの上限」を足す（目安 20分）
1. client/chat_client.py の validate_messages に、content が 2000 文字を超えたら ValueError にする規則を足す
2. 通信せずに止まることを、試験で確かめる（V05 の名前で書く）
3. 画面（web/app.js）にも、同じ上限の案内を出す

## 解答の方針
- 演習1：規則は server 側で決め、試験で確かめる。応答の形は変えない
- 演習2：上限は client 側で止める（通信しない）。試験では server の request_log が増えないことを確かめる
