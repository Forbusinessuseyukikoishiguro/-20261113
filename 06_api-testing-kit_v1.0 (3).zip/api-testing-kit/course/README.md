# Udemy 講座：モックでAPIテストする（Python・HTML/CSS/JS・Ubuntu・WSL・Windows）

## 概要
- 対象：Python と HTML・JavaScript の基本が分かる人（入門〜初級）
- 到達点：APIキーなしで、送信処理と画面を試験でき、本物へ切り替える前の確認方法が分かる
- 費用：APIの契約は不要
- 想定時間：講義 約75分＋演習 約40分

## 構成（10講義）
| 区分 | 講義 | 台本 | 目標 |
|---|---|---|---|
| 1 はじめに | L01 モックで試験する理由 | lectures/L01 | 費用・キー・揺れの問題を言える |
|  | L02 原理原則10か条 | lectures/L02 | 原則を、kit の場所と結びつける |
| 2 環境 | L03 Ubuntu・WSL・Windows で Python を用意する | lectures/L03 | 仮想環境を作って有効にできる |
|  | L04 VS Code で Python と試験を使う | lectures/L04 | テスト画面から実行、止めて確かめられる |
| 3 模倣サーバー | L05 チャット形式 API の形（ChatGPT 型で考える） | lectures/L05 | 送る形・受け取る形を言える |
|  | L06 模倣サーバーを起動し、外から呼ぶ | lectures/L06 | curl と Invoke-RestMethod で確かめられる |
| 4 送信処理 | L07 失敗を分け、安全にだけ再試行する | lectures/L07 | 429・5xx と 401 の違いを説明できる |
| 5 試験 | L08 契約・認証・入力の試験を書く | lectures/L08 | 失敗の試験を、同じ入力で繰り返せる |
|  | L09 画面（HTML・CSS・JS）を試験する | lectures/L09 | ブラウザで送信と案内を確かめられる |
| 6 まとめ | L10 本物へ切り替える手順と注意 | lectures/L10 | 段階的に確かめる順番を言える |

## 演習・クイズ
- exercises.md（3本、解答の方針つき）
- quiz.md（10問、解答つき）

## 制作の注意
- 録画の前に、`bash run_tests.sh` と `run_tests.ps1` を、それぞれの環境で実行して結果を確かめる（この kit の Ubuntu・Docker での結果は確認済み。Windows での実行は収録前に行う）
- ChatGPT 型 API の説明は、一般的な考え方として話す。項目名・料金・モデル名は、収録時点の公式ドキュメントで確認して差し替える
