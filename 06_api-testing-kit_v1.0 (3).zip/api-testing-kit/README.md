# モックで API をテストする（Python・HTML/CSS/JS・Ubuntu・WSL・Windows）

APIキーを使わず、チャット形式 API の送信処理と画面を、模倣サーバーで試験する教材キットです。

| フォルダ・ファイル | 内容 |
|---|---|
| server/mock_chat_server.py | 模倣サーバー（OpenAI 型の形で応答、失敗も再現） |
| client/chat_client.py | アプリ側の送信処理（検査・失敗の分類・安全な再試行） |
| tests/test_api_contract.py | 契約・認証・入力の検査・失敗の試験（17件、標準ライブラリのみ） |
| tests/test_web_browser.py | 画面（HTML・CSS・JS）の試験（5件、Playwright） |
| web/ | 画面（index.html、style.css、app.js） |
| run_tests.sh / run_tests.ps1 | Ubuntu・WSL / Windows で、まとめて実行 |
| docs-principles.md | 原理原則（10か条）、テストピラミッド、ChatGPT型 API の考え方 |
| docs-commands.md | コマンドの手引き（Ubuntu・WSL・Windows・VS Code） |
| course/ | Udemy 講座の台本（概要、10講義、演習、クイズ） |

## すぐ試す（Ubuntu / WSL）
```bash
cd api-testing-kit
bash run_tests.sh
```

## すぐ試す（Windows・PowerShell）
```powershell
cd api-testing-kit
powershell -ExecutionPolicy Bypass -File .\run_tests.ps1
```

## 注意
- この kit は、本物の API に接続しない。模倣の形は、本物の仕様と一致するとは限らない
- 本物へ切り替える前に、公式ドキュメントで仕様を確認し、キーは環境変数で渡すこと
