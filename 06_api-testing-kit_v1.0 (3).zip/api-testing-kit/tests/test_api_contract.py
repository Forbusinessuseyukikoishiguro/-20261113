"""
test_api_contract.py — 模倣サーバーに対する、送信処理の試験（APIキー不要）

実行（api-testing-kit のフォルダで）：
    python3 -m unittest -v tests/test_api_contract.py
試験の分類：
  C 契約（形）        ：送る形・受け取る形が正しいか
  A 認証              ：キーの有無・誤り
  E 失敗の扱い        ：429・5xx・通信断・タイムアウト・不正な応答
  V 入力の検査        ：送る前に、不正な入力を止める
"""
import os
import socket
import sys
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "server"))
sys.path.insert(0, os.path.join(HERE, "..", "client"))
from mock_chat_server import MockChatServer, MOCK_KEY  # noqa: E402
from chat_client import ChatClient, ApiError, DEFAULT_BASE_URL  # noqa: E402

MSG = [{"role": "user", "content": "来月の会議の議題を3つ挙げてください"}]


class ServerCase(unittest.TestCase):
    """各試験の前に、失敗の種類を指定した模倣サーバーを立てる"""
    fail_mode = "none"
    slow_seconds = 3.0

    def setUp(self):
        self.srv = MockChatServer(port=0, fail_mode=self.fail_mode, slow_seconds=self.slow_seconds)
        import threading
        threading.Thread(target=self.srv.serve_forever, daemon=True).start()
        self.addCleanup(self.srv.shutdown)
        self.addCleanup(self.srv.server_close)
        self.sleeps = []

    def client(self, key=MOCK_KEY, **kw):
        kw.setdefault("timeout", 1.0)
        return ChatClient(base_url=self.srv.base_url, api_key=key, sleep=self.sleeps.append, **kw)

    def requests_made(self):
        return len(self.srv.request_log)


class TestContract(ServerCase):
    def test_C01_contract_ok_returns_text(self):
        text = self.client().chat(MSG)
        self.assertTrue(text.startswith("【モック】"))
        self.assertIn("来月の会議", text)

    def test_C02_contract_reply_depends_on_last_user(self):
        a = self.client().chat([{"role": "user", "content": "AAA"}])
        b = self.client().chat([{"role": "user", "content": "BBB"}])
        self.assertNotEqual(a, b)
        self.assertIn("AAA", a)

    def test_C03_contract_long_input_is_cut(self):
        long = "あ" * 100
        text = self.client().chat([{"role": "user", "content": long}])
        self.assertIn("…", text)
        self.assertLess(len(text), 100)

    def test_C04_contract_request_has_path_and_auth(self):
        self.client().chat(MSG)
        last = self.srv.request_log[-1]
        self.assertEqual(last["path"], "/v1/chat/completions")
        self.assertEqual(last["auth"], f"Bearer {MOCK_KEY}")

    def test_C05_contract_default_url_is_local(self):
        self.assertTrue(DEFAULT_BASE_URL.startswith("http://127.0.0.1"))


class TestAuth(ServerCase):
    def test_A01_auth_empty_key_no_request(self):
        with self.assertRaises(ApiError) as cm:
            self.client(key="").chat(MSG)
        self.assertEqual(cm.exception.kind, "auth")
        self.assertEqual(self.requests_made(), 0, "キーが無いのに通信してはいけない")

    def test_A02_auth_wrong_key_401_no_retry(self):
        with self.assertRaises(ApiError) as cm:
            self.client(key="wrong").chat(MSG)
        self.assertEqual(cm.exception.kind, "auth")
        self.assertEqual(cm.exception.status, 401)
        self.assertEqual(self.requests_made(), 1, "401 は1回だけ送る（再試行しない）")


class TestValidation(ServerCase):
    def test_V01_validate_empty_messages(self):
        with self.assertRaises(ValueError):
            self.client().chat([])
        self.assertEqual(self.requests_made(), 0)

    def test_V02_validate_bad_role(self):
        with self.assertRaises(ValueError):
            self.client().chat([{"role": "robot", "content": "x"}])
        self.assertEqual(self.requests_made(), 0)

    def test_V03_validate_empty_content(self):
        with self.assertRaises(ValueError):
            self.client().chat([{"role": "user", "content": "   "}])

    def test_V04_validate_non_dict(self):
        with self.assertRaises(ValueError):
            self.client().chat(["こんにちは"])


class TestFailures(ServerCase):
    fail_mode = "429"

    def test_E01_fail_429_retries_then_rate_limit(self):
        with self.assertRaises(ApiError) as cm:
            self.client().chat(MSG)
        self.assertEqual(cm.exception.kind, "rate_limit")
        self.assertEqual(cm.exception.attempts, 3)
        self.assertEqual(self.requests_made(), 3)
        self.assertEqual(self.sleeps, [0.2, 0.4], "待ち時間は 0.2 秒、0.4 秒と増える")


class TestServerError(ServerCase):
    fail_mode = "500"

    def test_E02_fail_500_retries_then_server(self):
        with self.assertRaises(ApiError) as cm:
            self.client().chat(MSG)
        self.assertEqual(cm.exception.kind, "server")
        self.assertEqual(self.requests_made(), 3)


class TestSlow(ServerCase):
    fail_mode = "slow"
    slow_seconds = 2.0

    def test_E03_fail_slow_is_timeout(self):
        with self.assertRaises(ApiError) as cm:
            self.client(timeout=0.3, max_attempts=1).chat(MSG)
        self.assertEqual(cm.exception.kind, "timeout")


class TestBadJson(ServerCase):
    fail_mode = "badjson"

    def test_E04_fail_bad_json_no_retry(self):
        with self.assertRaises(ApiError) as cm:
            self.client().chat(MSG)
        self.assertEqual(cm.exception.kind, "bad_response")
        self.assertEqual(self.requests_made(), 1)


class TestNoChoices(ServerCase):
    fail_mode = "nochoices"

    def test_E05_fail_no_choices(self):
        with self.assertRaises(ApiError) as cm:
            self.client().chat(MSG)
        self.assertEqual(cm.exception.kind, "bad_response")


class TestNetworkDown(unittest.TestCase):
    def test_E06_fail_network_down(self):
        # 使われていないポートを探し、そこへ送る（サーバーは立てない）
        with socket.socket() as s:
            s.bind(("127.0.0.1", 0))
            port = s.getsockname()[1]
        c = ChatClient(base_url=f"http://127.0.0.1:{port}", api_key=MOCK_KEY, timeout=0.5,
                       max_attempts=2, sleep=lambda s: None)
        with self.assertRaises(ApiError) as cm:
            c.chat(MSG)
        self.assertEqual(cm.exception.kind, "network")
        self.assertEqual(cm.exception.attempts, 2)


if __name__ == "__main__":
    unittest.main(verbosity=2)
