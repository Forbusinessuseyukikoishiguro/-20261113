"""
test_web_browser.py — 画面（HTML・CSS・JavaScript）の試験。実ブラウザで、模倣サーバーに送る。

実行（api-testing-kit のフォルダで）：  python3 tests/test_web_browser.py
前提：pip install playwright、python -m playwright install chromium（Docker なら同梱）
確認：正常な送信、誤ったキーの案内、接続できないときの案内、空の入力、HTML の無害化
"""
import functools
import http.server
import os
import sys
import threading
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
KIT = os.path.join(HERE, "..")
sys.path.insert(0, os.path.join(KIT, "server"))
from mock_chat_server import MockChatServer  # noqa: E402

try:
    from playwright.sync_api import sync_playwright
except ImportError:  # 無い場合は、この試験だけ飛ばす
    sync_playwright = None


class _Quiet(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *a):
        pass


@unittest.skipIf(sync_playwright is None, "playwright が無いので、画面の試験は飛ばします")
class WebBrowserTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.api = MockChatServer(port=0, fail_mode="none")
        threading.Thread(target=cls.api.serve_forever, daemon=True).start()
        web = http.server.ThreadingHTTPServer(("127.0.0.1", 0), functools.partial(_Quiet, directory=os.path.join(KIT, "web")))
        threading.Thread(target=web.serve_forever, daemon=True).start()
        cls.web, cls.web_url = web, f"http://127.0.0.1:{web.server_address[1]}/index.html"
        cls.pw = sync_playwright().start()
        kw = {}
        if os.environ.get("PW_CHANNEL"):
            kw["channel"] = os.environ["PW_CHANNEL"]
        cls.browser = cls.pw.chromium.launch(**kw)

    @classmethod
    def tearDownClass(cls):
        cls.browser.close()
        cls.pw.stop()
        cls.web.shutdown()
        cls.web.server_close()
        cls.api.shutdown()
        cls.api.server_close()

    def page(self, endpoint=None):
        pg = self.browser.new_page()
        pg.goto(self.web_url)
        if endpoint:
            pg.fill("#endpoint", endpoint)
        return pg

    def send(self, pg):
        pg.click("#send")
        pg.wait_for_function("document.getElementById('status').textContent !== '送信しています…'", timeout=10000)

    def test_web_send_shows_reply(self):
        pg = self.page(endpoint=self.api.base_url)
        self.send(pg)
        self.assertIn("【モック】", pg.inner_text("#reply"))
        self.assertEqual(pg.inner_text("#status"), "届きました。")
        pg.close()

    def test_web_wrong_key_is_explained(self):
        pg = self.page(endpoint=self.api.base_url)
        pg.fill("#key", "wrong")
        self.send(pg)
        self.assertIn("APIキーが正しくありません", pg.inner_text("#status"))
        pg.close()

    def test_web_unreachable_server_is_explained(self):
        pg = self.page(endpoint="http://127.0.0.1:9")   # 何も動いていないポート
        self.send(pg)
        self.assertIn("接続できません", pg.inner_text("#status"))
        pg.close()

    def test_web_empty_text_is_blocked_without_request(self):
        before = len(self.api.request_log)
        pg = self.page(endpoint=self.api.base_url)
        pg.fill("#text", "   ")
        pg.click("#send")
        self.assertIn("送る文を入力", pg.inner_text("#status"))
        self.assertEqual(len(self.api.request_log), before, "空の入力は通信しない")
        pg.close()

    def test_web_html_in_reply_is_shown_as_text(self):
        # 応答に HTML が含まれても、実行されず文字として表示される
        pg = self.page(endpoint=self.api.base_url)
        pg.fill("#text", '<img src=x onerror="window.__x=1">')
        self.send(pg)
        self.assertEqual(pg.evaluate("typeof window.__x"), "undefined")
        self.assertEqual(pg.evaluate("document.querySelectorAll('#reply img').length"), 0)
        pg.close()


if __name__ == "__main__":
    unittest.main(verbosity=2)
