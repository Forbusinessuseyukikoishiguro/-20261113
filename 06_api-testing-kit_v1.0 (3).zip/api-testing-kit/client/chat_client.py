"""
chat_client.py — アプリ側の送信処理（チャット形式 API の呼び出し）

原理：
  1. 送る前に、入力を検査する（不正な入力は、通信せずに ValueError）
  2. APIキーが無ければ、通信せずに失敗させる（auth）
  3. 失敗の種類を分ける。再試行してよいもの（429・5xx・通信断・タイムアウト）だけ、待って再試行する
  4. 応答は、形を確かめてから取り出す（choices が無い・JSON でないものは bad_response）

既定の接続先は、模倣サーバー（127.0.0.1）。本物へ切り替えるときは base_url と api_key を変える。
"""
import json
import socket
import time
import urllib.error
import urllib.request

DEFAULT_BASE_URL = "http://127.0.0.1:8790"   # 模倣サーバーの既定の場所
RETRYABLE = {"rate_limit", "server", "network", "timeout"}


class ApiError(Exception):
    """送信の失敗。kind で種類を表す（auth / bad_request / rate_limit / server / network / timeout / bad_response）"""

    def __init__(self, kind, message, status=None, attempts=0):
        super().__init__(message)
        self.kind = kind
        self.status = status
        self.attempts = attempts


def validate_messages(messages):
    """送る前の検査。問題があれば ValueError（通信はしない）"""
    if not isinstance(messages, list) or not messages:
        raise ValueError("messages は1件以上のリストが必要です")
    for m in messages:
        if not isinstance(m, dict):
            raise ValueError("各 message は辞書（role と content）である必要があります")
        if m.get("role") not in ("system", "user", "assistant"):
            raise ValueError(f"role が不正です：{m.get('role')!r}")
        if not isinstance(m.get("content"), str) or not m["content"].strip():
            raise ValueError("content は空でない文字列である必要があります")


class ChatClient:
    def __init__(self, base_url=DEFAULT_BASE_URL, api_key="", model="mock-model",
                 timeout=5.0, max_attempts=3, backoff=(0.2, 0.4), sleep=time.sleep):
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self.model = model
        self.timeout = timeout
        self.max_attempts = max_attempts
        self.backoff = backoff
        self._sleep = sleep

    def _once(self, messages):
        body = json.dumps({"model": self.model, "messages": messages}, ensure_ascii=False).encode("utf-8")
        req = urllib.request.Request(
            f"{self.base_url}/v1/chat/completions", data=body, method="POST",
            headers={"Content-Type": "application/json", "Authorization": f"Bearer {self.api_key}"},
        )
        with urllib.request.urlopen(req, timeout=self.timeout) as res:
            return res.read().decode("utf-8")

    def chat(self, messages):
        validate_messages(messages)
        if not self.api_key:
            raise ApiError("auth", "APIキーが設定されていません（通信はしていません）", attempts=0)

        last = None
        for attempt in range(1, self.max_attempts + 1):
            try:
                raw = self._once(messages)
                return self._extract(raw, attempt)
            except ApiError as e:
                last = e
            except urllib.error.HTTPError as e:
                last = self._classify_http(e.code, attempt)
            except (socket.timeout, TimeoutError) as e:
                last = ApiError("timeout", "時間内に応答がありませんでした", attempts=attempt)
            except urllib.error.URLError as e:
                if isinstance(e.reason, (socket.timeout, TimeoutError)):
                    last = ApiError("timeout", "時間内に応答がありませんでした", attempts=attempt)
                else:
                    last = ApiError("network", "接続できませんでした", attempts=attempt)

            if last.kind not in RETRYABLE or attempt == self.max_attempts:
                last.attempts = attempt
                raise last
            self._sleep(self.backoff[min(attempt - 1, len(self.backoff) - 1)])
        raise last  # 到達しない想定

    def _classify_http(self, code, attempt):
        if code in (401, 403):
            return ApiError("auth", "APIキーが正しくありません", status=code, attempts=attempt)
        if code in (400, 404, 422):
            return ApiError("bad_request", "送信内容が正しくありません", status=code, attempts=attempt)
        if code == 429:
            return ApiError("rate_limit", "利用上限に達しました", status=code, attempts=attempt)
        if code >= 500:
            return ApiError("server", "サーバーで障害が起きました", status=code, attempts=attempt)
        return ApiError("bad_request", f"想定外の応答です（{code}）", status=code, attempts=attempt)

    def _extract(self, raw, attempt):
        """応答の形を確かめてから、本文を取り出す。形が違えば bad_response（再試行しない）"""
        try:
            data = json.loads(raw)
        except ValueError:
            raise ApiError("bad_response", "応答が JSON ではありません", attempts=attempt)
        choices = data.get("choices") if isinstance(data, dict) else None
        if not choices:
            raise ApiError("bad_response", "応答に choices がありません", attempts=attempt)
        try:
            content = choices[0]["message"]["content"]
        except (KeyError, TypeError, IndexError):
            raise ApiError("bad_response", "応答の message.content が見つかりません", attempts=attempt)
        if not isinstance(content, str):
            raise ApiError("bad_response", "message.content が文字列ではありません", attempts=attempt)
        return content
