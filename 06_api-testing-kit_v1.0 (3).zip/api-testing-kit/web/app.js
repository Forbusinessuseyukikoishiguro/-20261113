/* app.js — 画面の処理。送信・失敗の案内・表示だけを行う（APIの形は模倣サーバーの仕様に合わせる） */
(function () {
  "use strict";
  const $ = (id) => document.getElementById(id);
  const ui = { endpoint: $("endpoint"), key: $("key"), text: $("text"), send: $("send"), reply: $("reply"), status: $("status") };

  function setStatus(text, isError) {
    ui.status.textContent = text;
    ui.status.classList.toggle("error", Boolean(isError));
  }

  // 失敗の種類ごとに、分かる案内を出す（HTTP の状態で分ける）
  function explain(err) {
    if (err.name === "AbortError") return ["時間内に応答がありませんでした。もう一度お試しください。", true];
    if (err.name === "TypeError") return ["接続できません。模倣サーバーが起動しているか確認してください。", true];
    if (err.status === 401 || err.status === 403) return ["APIキーが正しくありません（練習用は test-key）。", true];
    if (err.status === 429) return ["利用上限に達しました。時間をおいて再実行してください。", true];
    if (err.status >= 500) return [`サーバーで障害が起きました（${err.status}）。`, true];
    if (err.status) return [`送信内容が正しくありません（${err.status}）。`, true];
    return ["予期しないエラーが起きました。", true];
  }

  async function send() {
    const text = ui.text.value.trim();
    if (text === "") { setStatus("送る文を入力してください。", true); return; }
    if (ui.key.value === "") { setStatus("APIキーを入力してください（練習用は test-key）。", true); return; }

    ui.send.disabled = true;
    setStatus("送信しています…");
    const ctl = new AbortController();
    const timer = setTimeout(() => ctl.abort(), 5000);
    try {
      const res = await fetch(`${ui.endpoint.value.replace(/\/+$/, "")}/v1/chat/completions`, {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${ui.key.value}` },
        body: JSON.stringify({ model: "mock-model", messages: [{ role: "user", content: text }] }),
        signal: ctl.signal,
      });
      if (!res.ok) throw Object.assign(new Error("http"), { status: res.status });
      const data = await res.json();
      const content = data && data.choices && data.choices[0] && data.choices[0].message
        ? data.choices[0].message.content : null;
      if (typeof content !== "string") throw new Error("bad_response");
      ui.reply.textContent = content;   // textContent で表示（HTML として解釈しない）
      setStatus("届きました。");
    } catch (err) {
      ui.reply.textContent = "返事を受け取れませんでした。";
      const [msg, isError] = explain(err);
      setStatus(msg, isError);
    } finally {
      clearTimeout(timer);
      ui.send.disabled = false;
    }
  }

  ui.send.addEventListener("click", send);
})();
