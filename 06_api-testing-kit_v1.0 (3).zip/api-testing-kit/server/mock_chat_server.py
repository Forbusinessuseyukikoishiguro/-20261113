"""
mock_chat_server.py — チャット形式 API の模倣サーバー（APIキー不要・課金なし）

目的：本物の API と同じ「形」で応答し、送信処理と画面を試験できるようにする。
      応答の中身は決まった規則で作る（AI ではない）。

エンドポイント：POST /v1/chat/completions
  ・Authorization: Bearer <キー>   … 正しいキーは MOCK_KEY（既定値 test-key）
  ・本文（JSON）：{"model": "...", "messages": [{"role": "user", "content": "..."}]}
  ・応答（JSON）：OpenAI 互換の形（id, object, choices[0].message.content, usage）

失敗を再現する（fail_mode）：
  none      正常
  429       利用上限（毎回）
  500       サーバー障害（毎回）
  slow      応答が遅い（slow_seconds 秒後に返す）
  badjson   200 だが本文が JSON ではない
  nochoices 200 だが choices が空

注意：ここでの「形」は学習用の模倣であり、本物の仕様そのものではない。
      本物の仕様は必ず公式ドキュメントで確認すること。
"""
import json
import os
import sys
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

MOCK_KEY = "test-key"
VALID_ROLES = {"system", "user", "assistant"}


class _Handler(BaseHTTPRequestHandler):
    server_version = "MockChat/1.0"

    def log_message(self, *args):  # 試験中の出力を静かにする
        pass

    def _send(self, code, obj=None, raw=None):
        body = raw if raw is not None else json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Headers", "Authorization, Content-Type")
        self.send_header("Access-Control-Allow-Methods", "POST, OPTIONS")
        self.end_headers()
        self.wfile.write(body)

    def _error(self, code, message, err_type, err_code):
        self._send(code, {"error": {"message": message, "type": err_type, "code": err_code}})

    def do_OPTIONS(self):
        self._send(204, raw=b"")

    def do_POST(self):
        srv = self.server
        srv.request_log.append({"path": self.path, "auth": self.headers.get("Authorization")})
        if self.path != "/v1/chat/completions":
            return self._error(404, "not found", "invalid_request_error", "not_found")

        length = int(self.headers.get("Content-Length", "0") or 0)
        raw = self.rfile.read(length)
        try:
            data = json.loads(raw.decode("utf-8") or "{}")
        except (ValueError, UnicodeDecodeError):
            return self._error(400, "リクエストの JSON が不正です", "invalid_request_error", "invalid_json")

        # 認証：キーの有無と一致を確かめる
        auth = self.headers.get("Authorization") or ""
        if not auth.startswith("Bearer "):
            return self._error(401, "APIキーがありません", "invalid_request_error", "invalid_api_key")
        if auth[len("Bearer "):] != srv.valid_key:
            return self._error(401, "APIキーが正しくありません", "invalid_request_error", "invalid_api_key")

        # 入力の検査：model と messages
        if not isinstance(data, dict) or not isinstance(data.get("model"), str) or not data["model"]:
            return self._error(400, "model が必要です", "invalid_request_error", "missing_model")
        msgs = data.get("messages")
        if not isinstance(msgs, list) or len(msgs) == 0:
            return self._error(400, "messages は1件以上の配列です", "invalid_request_error", "empty_messages")
        for m in msgs:
            if not isinstance(m, dict) or m.get("role") not in VALID_ROLES or not isinstance(m.get("content"), str):
                return self._error(400, "messages の形式が不正です", "invalid_request_error", "invalid_message")

        # 失敗の再現
        mode = srv.fail_mode
        if mode == "429":
            return self._error(429, "利用上限に達しました", "rate_limit_error", "rate_limit_exceeded")
        if mode == "500":
            return self._error(500, "サーバー内部のエラー", "server_error", "internal_error")
        if mode == "slow":
            time.sleep(srv.slow_seconds)
        if mode == "badjson":
            return self._send(200, raw=b"<html>not json</html>")

        # 正常応答：最後の user の発言から、決まった規則で返答を作る
        last_user = next((m["content"] for m in reversed(msgs) if m["role"] == "user"), "")
        if mode == "nochoices":
            choices = []
        else:
            head = last_user[:40] + ("…" if len(last_user) > 40 else "")
            choices = [{
                "index": 0,
                "message": {"role": "assistant", "content": f"【モック】受け取った内容：{head}"},
                "finish_reason": "stop",
            }]
        prompt_chars = sum(len(m["content"]) for m in msgs)
        completion_chars = len(choices[0]["message"]["content"]) if choices else 0
        self._send(200, {
            "id": "chatcmpl-mock-0001",
            "object": "chat.completion",
            "created": int(time.time()),
            "model": data["model"],
            "choices": choices,
            # トークン数は模倣のため文字数で近似している（本物の数え方とは異なる）
            "usage": {"prompt_tokens": prompt_chars, "completion_tokens": completion_chars,
                      "total_tokens": prompt_chars + completion_chars},
        })


class MockChatServer(ThreadingHTTPServer):
    daemon_threads = True

    def __init__(self, port=0, fail_mode="none", valid_key=MOCK_KEY, slow_seconds=3.0):
        super().__init__(("127.0.0.1", port), _Handler)
        self.fail_mode = fail_mode
        self.valid_key = valid_key
        self.slow_seconds = slow_seconds
        self.request_log = []

    @property
    def base_url(self):
        return f"http://127.0.0.1:{self.server_address[1]}"


if __name__ == "__main__":
    port = int(os.environ.get("PORT", "8790"))
    mode = os.environ.get("MOCK_FAIL", "none")
    srv = MockChatServer(port=port, fail_mode=mode)
    print(f"mock chat server: http://127.0.0.1:{port}/v1/chat/completions（失敗の模倣：{mode}）", flush=True)
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        sys.exit(0)
