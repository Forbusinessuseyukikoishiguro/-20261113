# run_tests.ps1 — Windows（PowerShell）で、API の模倣試験をまとめて実行する
# 使い方（このフォルダで）：powershell -ExecutionPolicy Bypass -File .\run_tests.ps1
$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot
$py = if (Get-Command py -ErrorAction SilentlyContinue) { "py" } else { "python" }
Write-Host "== Python: $(& $py --version)"
Write-Host "== 1) 契約・認証・失敗の試験（APIキーは使わない）"
& $py -m unittest -v tests/test_api_contract.py
if ($LASTEXITCODE -ne 0) { exit 1 }
Write-Host "== 2) 画面の試験（ブラウザ）"
& $py tests/test_web_browser.py
if ($LASTEXITCODE -ne 0) { exit 1 }
Write-Host "== すべて完了" -ForegroundColor Green
