#!/usr/bin/env bash
# run_tests.sh — Ubuntu / WSL（Ubuntu）で、API の模倣試験をまとめて実行する
# 使い方（このフォルダで）：bash run_tests.sh
set -euo pipefail
cd "$(dirname "$0")"
PY="${PYTHON:-python3}"
echo "== Python: $($PY --version)"
echo "== 1) 契約・認証・失敗の試験（Python 標準のみ。APIキーは使わない）"
$PY -m unittest -v tests/test_api_contract.py
echo "== 2) 画面の試験（ブラウザ。playwright が無い場合は飛ばす）"
$PY tests/test_web_browser.py
echo "== すべて完了"
