# ============================================================
# mock_run.py  偽物の Whisper で transcribe.py を「そのまま最後まで」動かす
# 目的：3GBのモデルなしで、プログラム全体の流れ（探す→読む→保存）を目で見て確かめる
# 実行: docker compose run --rm test python mock_run.py   （または python mock_run.py）
# ============================================================
import sys                                              # 読み込み済みの部品の登録台帳（sys.modules）を扱う標準の部品
import types                                            # その場で「部品（モジュール）」を作るための標準の部品
import tempfile                                         # 使い終わったら自動で消える一時フォルダを作る標準の部品
from pathlib import Path                                # ファイルやフォルダの場所を扱いやすくする標準の部品


class FakeSegment:                                      # 「文字起こしの1区間」の偽物の型を定義する
    def __init__(self, start, end, text):               # 作るときに、開始秒・終了秒・文章を受け取る
        self.start, self.end, self.text = start, end, text  # 3つの値を、本物と同じ名前で覚えておく


class FakeInfo:                                         # 「音声の情報」の偽物の型を定義する
    language = "ja"                                     # 検出した言語は、いつでも日本語ということにする
    duration = 3.0                                      # 音声の長さは、いつでも3秒ということにする


class FakeWhisperModel:                                 # 本物の WhisperModel の偽物を定義する
    def __init__(self, *args, **kwargs):                # 本物と同じく、どんな引数でも受け取る
        print(f"  [偽物] モデルを作るふり: 引数={args} 設定={kwargs}")  # 「本物なら3GBを読み込むところ」を画面に出して、偽物だと分かるようにする

    def transcribe(self, path, **kwargs):               # 本物と同じ名前の「文字起こし」の動作を用意する
        print(f"  [偽物] 文字起こしするふり: {Path(path).name} 指定={kwargs}")  # どのファイルを、どんな指定で頼まれたかを画面に出す
        return iter([FakeSegment(0.0, 1.5, " こんにちは "), FakeSegment(1.5, 3.0, " テストです ")]), FakeInfo()  # 決まった2区間を、本物と同じ形（区間, 情報）で返す


fake_module = types.ModuleType("faster_whisper")        # 「faster_whisper」という名前の空の部品をその場で作る
fake_module.WhisperModel = FakeWhisperModel             # その中に WhisperModel として偽物を入れる
sys.modules["faster_whisper"] = fake_module             # 「faster_whisper を import したら、これを渡す」と登録する（必ず transcribe を import する前に行う）

import transcribe                                       # 偽物を登録したあとで、本体 transcribe.py を読み込む（この順番が大事）

with tempfile.TemporaryDirectory() as tmp:              # 一時フォルダを作る。with を抜けると、中身ごと自動で消える
    in_dir = Path(tmp) / "input"                        # 一時フォルダの中の、入力用フォルダの場所
    out_dir = Path(tmp) / "output"                      # 同じく、出力用フォルダの場所
    in_dir.mkdir()                                      # 入力用フォルダを実際に作る
    (in_dir / "demo.wav").write_bytes(b"dummy")         # ダミーの音声ファイルを置く（偽物は中身を見ないので何でもよい）
    transcribe.INPUT_DIR = in_dir                       # transcribe.py の入力フォルダを、一時フォルダに差し替える
    transcribe.OUTPUT_DIR = out_dir                     # 出力フォルダも一時フォルダに差し替える（本物の data/ を汚さない）

    print("=== transcribe.main() を実行 ===")           # これから本体を動かすことを画面に出す
    code = transcribe.main()                            # 本体を最後まで実行し、戻り値（0=成功 / 1=失敗）を受け取る
    print(f"=== 終了コード: {code} ===")                 # 終了コードを画面に出す

    for f in sorted(out_dir.iterdir()):                 # 出力フォルダにできたファイルを、名前順に1つずつ取り出す
        print(f"--- {f.name} ---")                       # ファイル名を見出しとして出す
        print(f.read_text(encoding="utf-8"))            # ファイルの中身を読んで画面に出す（文章だけ／時刻つきの2種類が見える）

sys.exit(code)                                          # 本体と同じ終了コードで、このスクリプトも終わる
