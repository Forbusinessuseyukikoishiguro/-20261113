# Windows + VS Code + Docker で Whisper large-v3 を動かす（受講生用）

> 画面の名称・手順は変わることがあります。インストールは必ず公式サイトの最新手順に従ってください。
> 公式：Docker Desktop for Windows（docs.docker.com）／ VS Code（code.visualstudio.com）

## 0. このフォルダの中身
1. `transcribe.py` … 本体。音声を文字にする Python（全行コメント付き）
2. `Dockerfile` … Python と部品が入った「箱」の作り方
3. `docker-compose.yml` … 箱の起動設定（モデル名・言語・フォルダの接続）
4. `requirements.txt` … 入れる Python 部品の一覧
5. `.vscode/tasks.json` … VS Code から1クリックで実行するタスク
6. `data/input` … **ここに音声を置く** ／ `data/output` … **ここに結果が出る**
7. `tests/` … 偽物の Whisper でテストする pytest 一式（`conftest.py` と `test_transcribe.py`、全行コメント付き）
8. `mock_run.py` … 偽物の Whisper で本体を最後まで動かして見せるスクリプト（全行コメント付き）
9. `requirements-dev.txt` … テスト用の部品（pytest）

## 1. 事前準備（1回だけ）
1. Windows 10/11 のパソコンを用意する（メモリ **16GB 以上を推奨**。large-v3 を CPU で動かすため）
2. **Docker Desktop** をインストールして起動する（WSL 2 を使う設定が標準）
3. **Visual Studio Code** をインストールする
4. VS Code でこのフォルダを開く（「ファイル → フォルダーを開く」）
5. 右下に出る「おすすめの拡張機能をインストール」を許可する（Python と Docker）
6. ターミナルを開き `docker --version` と入力し、バージョンが表示されることを確認する

## 2. 実行する
1. 音声ファイル（mp3 / wav / m4a など）を `data\input` フォルダに入れる
2. VS Code のメニュー「ターミナル → タスクの実行」→ **1. イメージをビルド**（初回のみ数分）
3. 同じく「タスクの実行」→ **2. 文字起こしを実行**
4. 初回は **モデル（約3GB）のダウンロード** があるため、しばらく待つ（2回目以降は再利用される）
5. `data\output` に `〇〇.txt`（文章だけ）と `〇〇_timestamp.txt`（時刻つき）ができる

タスクを使わず、ターミナルに直接打つ場合は次の2行です。

```powershell
docker compose build
docker compose run --rm whisper
```

## 3. まず速く試したいとき
`docker-compose.yml` の `WHISPER_MODEL: large-v3` を `small` または `tiny` に書き換えて、もう一度「文字起こしを実行」します。
精度は下がりますが、ダウンロードも処理も速くなります。動作確認ができたら large-v3 に戻します。

## 4. 設定を変える場所（docker-compose.yml）
1. `WHISPER_MODEL` … 使うモデル（large-v3 / small / tiny など）
2. `WHISPER_LANGUAGE` … ja＝日本語、en＝英語、空欄＝自動判定
3. `WHISPER_DEVICE` / `WHISPER_COMPUTE_TYPE` … 通常は `cpu` / `int8` のまま

## 5. つまずき早見表
1. **`docker: command not found` / 接続エラー**：Docker Desktop が起動しているか確認する（タスクバーのクジラのアイコン）
2. **メモリ不足で落ちる**：Docker Desktop の設定（WSL 2 に割り当てるメモリ）を増やす／`small` を使う
3. **「音声ファイルがありません」と出る**：`data\input` に入れたか、拡張子が対応形式か確認する
4. **とても遅い**：large-v3 を CPU で動かすためです。長い音声は `small` で試すか、Colab（GPU）を使う
5. **音声が外部に出るか心配**：この構成は、モデルをダウンロードした後の文字起こしを自分のPC内で行います（音声は外部サービスへ送りません）

## 6. モックで動かす（モデルのダウンロードなし・1秒で終わる）
本物の Whisper（約3GB）を使わず、「偽物の Whisper」に差し替えて、自分のコードの動きを確かめます。

1. VS Code のメニュー「ターミナル → タスクの実行」→ **3. 偽物で動かす（モック実行）**
   画面に「[偽物] モデルを作るふり」と出て、`demo.txt` の中身（こんにちは／テストです）が表示されます
2. 同じく「タスクの実行」→ **4. テストを実行（pytest）**
   `8 passed` と出れば成功です
3. 直接打つ場合（PowerShell）：
   ```powershell
   docker compose run --rm test
   docker compose run --rm test sh -c "pip install -q -r requirements-dev.txt && python mock_run.py"
   ```
4. Python が自分の PC に入っている人は、Docker なしでも `pip install pytest` のあと `python -m pytest -q tests` で動きます

### 読む順番（おすすめ）
1. `mock_run.py` … 偽物の作り方と、差し替えの順番（**偽物を登録してから transcribe を import**）
2. `tests/conftest.py` … 偽物を全テストで共有する方法（fixture）
3. `tests/test_transcribe.py` … 8本のテスト。「記録を取り出して assert する」型を見る

### 注意
1. モックで確認できるのは「自分のコードの呼び方と後処理」だけです。本物のモデルが返す文字の品質は、**必ず本物で別に確認**します
2. 偽物にするのは「外部との境目（モデル・API・ファイル）」だけにします。自分のコードまで偽物にすると、何も確かめていないテストになります

## 7. 補足（動作確認の範囲）
1. `transcribe.py` の読み込み・保存の処理と、`docker-compose.yml` の文法は確認済みです
2. `tests/` の8件と `mock_run.py` は、偽物の Whisper で実行し成功を確認済みです（本体をわざと壊すと、テストが失敗することも確認しました）
3. 実際の Docker ビルドと large-v3 のダウンロードは、作成環境の制限により**未実施**です。授業前に、講師のWindows環境で一度通して動作確認してください
4. NVIDIA GPU を Docker で使う構成は、この教材では扱いません（CPU 実行を前提にしています）
