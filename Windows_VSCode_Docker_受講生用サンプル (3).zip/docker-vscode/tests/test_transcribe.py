# ============================================================
# test_transcribe.py  transcribe.py を「偽物の Whisper」でテストする
# 本物のモデル・GPU・音声がなくても、自分の書いたコードの動きを確かめられる
# 実行: docker compose run --rm test   （または python -m pytest -q tests）
# ============================================================
import pytest                                           # テストの道具。fixture（下ごしらえ）を作るために読み込む
import transcribe                                       # テスト対象の transcribe.py を読み込む（conftest.py が先に偽物を登録済み）


@pytest.fixture                                         # 「テストが引数で名前を呼ぶと、この関数の結果を渡す」下ごしらえの印
def dirs(tmp_path, monkeypatch):                        # tmp_path=テスト専用の一時フォルダ、monkeypatch=一時的な差し替え道具（どちらも pytest が用意）
    in_dir = tmp_path / "input"                         # 一時フォルダの中に、入力用フォルダの場所を決める
    out_dir = tmp_path / "output"                       # 同じく出力用フォルダの場所を決める
    in_dir.mkdir()                                      # 入力用フォルダを実際に作る（出力用は main() が作るので作らない）
    monkeypatch.setattr(transcribe, "INPUT_DIR", in_dir)    # transcribe.py の INPUT_DIR を、このテスト中だけ一時フォルダに差し替える
    monkeypatch.setattr(transcribe, "OUTPUT_DIR", out_dir)  # OUTPUT_DIR も差し替える（本物の /data/output を汚さない）
    return in_dir, out_dir                              # 2つのフォルダの場所をテストに渡す


def test_find_audio_files_only_audio(dirs):             # テスト1：音声だけを、名前順で見つけるか
    in_dir, _ = dirs                                    # 入力フォルダの場所を受け取る（出力は使わないので _ に捨てる）
    (in_dir / "b.MP3").write_bytes(b"x")                # 大文字の拡張子 .MP3 のダミーファイルを作る（中身は何でもよい）
    (in_dir / "a.wav").write_bytes(b"x")                # .wav のダミーファイルを作る
    (in_dir / "memo.txt").write_text("x")               # 音声ではない .txt も混ぜておく（無視されるはず）
    names = [p.name for p in transcribe.find_audio_files()]  # 見つかったファイルの名前だけを、リストにして取り出す
    assert names == ["a.wav", "b.MP3"]                  # 音声2つだけが、名前順で見つかったことを確認する（違えばテスト失敗）


def test_find_audio_files_missing_dir(tmp_path, monkeypatch):  # テスト2：入力フォルダが無いとき、落ちずに空で返すか
    monkeypatch.setattr(transcribe, "INPUT_DIR", tmp_path / "nothing")  # 存在しないフォルダの場所に差し替える
    assert transcribe.find_audio_files() == []          # エラーにならず、空のリストが返ることを確認する


def test_main_returns_1_when_no_audio(dirs, capsys):    # テスト3：音声が無いとき、失敗(1)で終わり、案内を出すか
    assert transcribe.main() == 1                       # 音声が1つも無い状態で main() を動かし、戻り値が1（失敗）か確認する
    assert "音声ファイルがありません" in capsys.readouterr().out  # capsys=画面表示の記録。案内メッセージが出ていたか確認する


def test_main_writes_plain_and_timestamp_files(dirs):   # テスト4：2種類の txt が正しい中身で出るか
    in_dir, out_dir = dirs                              # 入力・出力フォルダの場所を受け取る
    (in_dir / "demo.wav").write_bytes(b"dummy")         # ダミーの音声ファイルを置く（偽物の Whisper は中身を見ない）
    assert transcribe.main() == 0                       # main() を動かし、成功(0)で終わったか確認する
    plain = (out_dir / "demo.txt").read_text(encoding="utf-8")            # 「文章だけ」のファイルを読み込む
    stamped = (out_dir / "demo_timestamp.txt").read_text(encoding="utf-8")  # 「時刻つき」のファイルを読み込む
    assert plain == "こんにちは\nテストです"             # 前後の空白が取れ、改行でつながっていることを確認する
    assert "[    0.0 -     1.5] こんにちは" in stamped   # 時刻つきの1行目が、決めた書式になっていることを確認する


def test_model_is_loaded_with_settings(dirs, monkeypatch, reset_fake):  # テスト5：設定がモデルの作り方に伝わるか
    in_dir, _ = dirs                                    # 入力フォルダの場所を受け取る
    (in_dir / "demo.wav").write_bytes(b"dummy")         # ダミーの音声を置く
    monkeypatch.setattr(transcribe, "MODEL_NAME", "small")  # モデル名を small に差し替える
    monkeypatch.setattr(transcribe, "DEVICE", "cpu")        # 計算する機械を cpu に差し替える
    monkeypatch.setattr(transcribe, "COMPUTE_TYPE", "int8")  # 数値形式を int8 に差し替える
    transcribe.main()                                   # main() を動かす（偽物の WhisperModel が作られ、設定が記録される）
    args, kwargs = reset_fake.init_calls[0]             # 1回目に「どんな引数で作られたか」の記録を取り出す
    assert args[0] == "small"                           # 1番目の引数（モデル名）が small か確認する
    assert kwargs["device"] == "cpu"                    # device が cpu か確認する
    assert kwargs["compute_type"] == "int8"             # compute_type が int8 か確認する


def test_transcribe_options(dirs, monkeypatch, reset_fake):  # テスト6：文字起こしの指定（言語・VAD・ビーム幅）が渡るか
    in_dir, _ = dirs                                    # 入力フォルダの場所を受け取る
    (in_dir / "demo.wav").write_bytes(b"dummy")         # ダミーの音声を置く
    monkeypatch.setattr(transcribe, "LANGUAGE", "ja")   # 言語を日本語に差し替える
    transcribe.main()                                   # main() を動かす
    path, kwargs = reset_fake.transcribe_calls[0]       # 「どのファイルを、どんな指定で頼まれたか」の記録を取り出す
    assert path.endswith("demo.wav")                    # 渡されたファイルが demo.wav か確認する
    assert kwargs["language"] == "ja"                   # 言語が ja か確認する
    assert kwargs["vad_filter"] is True                 # 無音を飛ばす指定（vad_filter）が True か確認する
    assert kwargs["beam_size"] == 5                     # ビーム幅が5か確認する


def test_empty_language_means_auto_detect(dirs, monkeypatch, reset_fake):  # テスト7：言語が空なら「自動判定(None)」になるか
    in_dir, _ = dirs                                    # 入力フォルダの場所を受け取る
    (in_dir / "demo.wav").write_bytes(b"dummy")         # ダミーの音声を置く
    monkeypatch.setattr(transcribe, "LANGUAGE", "")     # 言語を空っぽに差し替える
    transcribe.main()                                   # main() を動かす
    _, kwargs = reset_fake.transcribe_calls[0]          # 文字起こし依頼の記録を取り出す（ファイル名は使わないので _ に捨てる）
    assert kwargs["language"] is None                   # 空っぽが None（自動判定）に変わって渡されたか確認する


def test_two_audio_files_make_four_outputs(dirs):       # テスト8：2ファイルなら、2種類×2＝4つの結果が出るか
    in_dir, out_dir = dirs                              # 入力・出力フォルダの場所を受け取る
    (in_dir / "one.wav").write_bytes(b"dummy")          # 1つめのダミー音声を置く
    (in_dir / "two.mp3").write_bytes(b"dummy")          # 2つめのダミー音声を置く
    transcribe.main()                                   # main() を動かす
    names = sorted(p.name for p in out_dir.iterdir())   # 出力フォルダにできたファイル名を、名前順に集める
    assert names == ["one.txt", "one_timestamp.txt", "two.txt", "two_timestamp.txt"]  # 4つ全部できたか確認する
