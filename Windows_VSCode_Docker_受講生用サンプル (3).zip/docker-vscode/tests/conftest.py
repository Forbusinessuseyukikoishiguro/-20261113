# ============================================================
# conftest.py  pytest が「テストより先に」自動で読み込む特別なファイル
# ここで faster_whisper（本物のモデル）を「偽物」に入れ替える
# ============================================================
import sys                                              # Python が部品を探す場所（sys.path）や、読み込み済みの部品（sys.modules）を扱う標準の部品
import types                                            # その場で「部品（モジュール）」を作るための標準の部品
from pathlib import Path                                # ファイルやフォルダの場所を扱いやすくする標準の部品
import pytest                                           # テスト用の道具。fixture（テストの下ごしらえ）を使うために読み込む

ROOT = Path(__file__).resolve().parent.parent           # このファイルの2つ上のフォルダ（= transcribe.py があるフォルダ）の場所
sys.path.insert(0, str(ROOT))                           # そのフォルダを import の探し先の先頭に足す（テストから transcribe.py を読めるようにする）


class FakeSegment:                                      # 「文字起こしの1区間」の偽物を作るための型（クラス）を定義する
    def __init__(self, start, end, text):               # 作るときに、開始秒・終了秒・文章を受け取る
        self.start = start                              # 開始秒を覚えておく（本物の segment.start と同じ名前にする）
        self.end = end                                  # 終了秒を覚えておく（本物の segment.end と同じ名前）
        self.text = text                                # 文章を覚えておく（本物の segment.text と同じ名前）


class FakeInfo:                                         # 「音声の情報」の偽物を作るための型を定義する
    language = "ja"                                     # 検出した言語は、いつでも日本語ということにする
    duration = 3.0                                      # 音声の長さは、いつでも3秒ということにする


class FakeWhisperModel:                                 # 本物の WhisperModel の偽物を定義する（3GBのモデルは読み込まない）
    init_calls = []                                     # 「どんな設定で作られたか」を記録するリスト（箱）。型に1つだけ持たせる
    transcribe_calls = []                               # 「どんな指定で文字起こしを頼まれたか」を記録するリスト

    def __init__(self, *args, **kwargs):                # 本物と同じように、どんな引数でも受け取れるようにする
        FakeWhisperModel.init_calls.append((args, kwargs))  # 受け取った引数をそのまま記録する（あとでテストが中身を確かめる）

    def transcribe(self, path, **kwargs):               # 本物と同じ名前の「文字起こし」の動作を用意する
        FakeWhisperModel.transcribe_calls.append((path, kwargs))  # 渡されたファイルと指定を記録する
        segments = iter([                               # 区間の一覧を iter() で包む（本物は「呼ばれて初めて処理が走る」ジェネレータなので同じ性質にする）
            FakeSegment(0.0, 1.5, " こんにちは "),        # 1つめの区間（わざと前後に空白を付けて、strip() が効くか確かめる）
            FakeSegment(1.5, 3.0, " テストです "),        # 2つめの区間
        ])                                              # iter([ ... ]) の閉じカッコ
        return segments, FakeInfo()                     # 本物と同じく（区間, 音声情報）の2つを返す


fake_module = types.ModuleType("faster_whisper")        # 「faster_whisper」という名前の空の部品（モジュール）をその場で作る
fake_module.WhisperModel = FakeWhisperModel             # その部品の中に WhisperModel という名前で偽物を入れる
sys.modules["faster_whisper"] = fake_module             # 「faster_whisper を import したら、これを渡す」と登録する（本物が入っていても偽物が優先される）


@pytest.fixture(autouse=True)                           # 「全部のテストの前に、自動で下の関数を実行する」という印
def reset_fake():                                       # テストごとに記録を空に戻す下ごしらえの関数
    FakeWhisperModel.init_calls.clear()                 # 前のテストの「作られ方の記録」を消す
    FakeWhisperModel.transcribe_calls.clear()           # 前のテストの「文字起こし依頼の記録」を消す
    yield FakeWhisperModel                              # ここでテストを実行する（テスト側は引数 reset_fake で偽物の型を受け取れる）
