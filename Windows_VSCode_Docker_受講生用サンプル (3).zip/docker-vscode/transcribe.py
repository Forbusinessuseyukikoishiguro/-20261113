# ============================================================
# transcribe.py  音声ファイルを Whisper large-v3 で文字にするサンプル
# 使い方: data/input に音声を置いて実行 → data/output に .txt が出る
# すべてのコード行に、右側へ「この行が何をしているか」を書いてあります
# ============================================================
import os                                    # 環境変数（設定値）を読むための Python 標準の部品
import sys                                   # プログラムの終了コード（成功0/失敗1）を返すための標準の部品
import time                                  # 処理にかかった時間をはかるための標準の部品
from pathlib import Path                     # ファイルやフォルダの場所を扱いやすくする標準の部品
from faster_whisper import WhisperModel      # Whisper を高速に動かす部品（requirements.txt で入れたもの）

# ---------- 設定（docker-compose.yml の environment で書き換えられる） ----------
MODEL_NAME = os.getenv("WHISPER_MODEL", "large-v3")          # 使うモデル名。設定がなければ large-v3（試すだけなら small や tiny でも可）
LANGUAGE = os.getenv("WHISPER_LANGUAGE", "ja")               # 音声の言語。ja=日本語、en=英語、空っぽ("")なら自動判定
DEVICE = os.getenv("WHISPER_DEVICE", "cpu")                  # 計算に使う機械。Windows の Docker は基本 cpu
COMPUTE_TYPE = os.getenv("WHISPER_COMPUTE_TYPE", "int8")     # 数値の精度。int8 は CPU 向けの軽い形式（メモリ節約）
INPUT_DIR = Path(os.getenv("INPUT_DIR", "/data/input"))      # 音声ファイルを置くフォルダ（コンテナの中の場所）
OUTPUT_DIR = Path(os.getenv("OUTPUT_DIR", "/data/output"))   # 文字起こし結果を書き出すフォルダ
MODEL_DIR = os.getenv("MODEL_DIR", "/models")                # ダウンロードしたモデルの保存場所（2回目以降は再利用）
AUDIO_EXTS = {".mp3", ".wav", ".m4a", ".flac", ".ogg", ".mp4", ".webm"}  # 対応する拡張子の一覧（これ以外は無視）


def find_audio_files():                                      # 音声ファイルを探す関数を定義する
    """INPUT_DIR の中から音声ファイルを探して、名前順のリストで返す。"""  # この関数の説明文（実行には影響しない）
    if not INPUT_DIR.exists():                               # 入力フォルダが存在しないなら
        return []                                            # 「見つからなかった」として空のリストを返す
    return sorted(                                           # 見つけたファイルを名前順に並べて返す
        p for p in INPUT_DIR.iterdir()                       # フォルダの中身を1つずつ取り出して
        if p.is_file() and p.suffix.lower() in AUDIO_EXTS    # ファイルで、かつ拡張子（小文字にして）が音声の一覧にあるものだけ選ぶ
    )                                                        # sorted( ... ) の閉じカッコ


def transcribe_one(model, audio_path):                       # 1つの音声を文字にする関数を定義する
    """1ファイルを文字起こしして、(区間のリスト, 言語情報) を返す。"""  # この関数の説明文
    segments, info = model.transcribe(                       # Whisper に文字起こしを依頼する（結果は2つ返ってくる）
        str(audio_path),                                     # 音声ファイルの場所（文字列にして渡す）
        language=LANGUAGE or None,                           # 言語。空っぽなら None（=自動判定）にする
        beam_size=5,                                         # 候補を5本たどって最も良い文を選ぶ（大きいほど丁寧で遅い）
        vad_filter=True,                                     # 無音の部分を飛ばす（幻覚＝ありもしない文字の出力を減らす）
    )                                                        # transcribe( ... ) の閉じカッコ
    return list(segments), info                              # segments は「呼ばれて初めて処理が走る」ので list() で全部取り出す

def main():                                                  # プログラム全体の流れを書く関数を定義する
    files = find_audio_files()                               # 音声ファイルを探して files に入れる
    if not files:                                            # 1つも見つからなかったら
        print(f"音声ファイルがありません: {INPUT_DIR} に mp3/wav などを置いてください")  # 置き場所を画面に表示する
        return 1                                             # 失敗（1）で終了する
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)            # 出力フォルダを作る（すでにあってもエラーにしない）
    print(f"モデル {MODEL_NAME} を読み込みます（初回は約3GBのダウンロードで数分かかります）")  # 初回は待つことを知らせる
    started = time.perf_counter()                            # 開始時刻を記録する（あとで経過時間を出すため）
    model = WhisperModel(                                    # モデルを読み込む（メモリに展開する）
        MODEL_NAME,                                          # どのモデルか
        device=DEVICE,                                       # どの機械で計算するか
        compute_type=COMPUTE_TYPE,                           # どの数値形式で計算するか
        download_root=MODEL_DIR,                             # ダウンロード先（コンテナを消しても残るフォルダ）
    )                                                        # WhisperModel( ... ) の閉じカッコ
    print(f"読み込み完了（{time.perf_counter() - started:.1f}秒）")  # かかった秒数を小数1桁で表示する
    for audio in files:                                      # 見つかった音声ファイルを1つずつ処理する
        print(f"文字起こし中: {audio.name}")                  # 今どのファイルを処理しているか表示する
        segments, info = transcribe_one(model, audio)        # 上で定義した関数で、このファイルを文字にする
        plain = "\n".join(s.text.strip() for s in segments)  # 区間ごとの文章を、改行でつないだ「文章だけ」のテキストにする
        stamped = "\n".join(                                 # 「時刻つき」のテキストも作る
            f"[{s.start:7.1f} - {s.end:7.1f}] {s.text.strip()}" for s in segments  # 開始秒 - 終了秒 と文章を1行にする
        )                                                    # join( ... ) の閉じカッコ
        (OUTPUT_DIR / f"{audio.stem}.txt").write_text(plain, encoding="utf-8")                   # 文章だけを 元の名前.txt に保存する
        (OUTPUT_DIR / f"{audio.stem}_timestamp.txt").write_text(stamped, encoding="utf-8")       # 時刻つきを 元の名前_timestamp.txt に保存する
        print(f"  完了: 言語={info.language} 音声の長さ={info.duration:.1f}秒 → {audio.stem}.txt")  # 結果の要約を表示する
    print(f"すべて完了しました（合計 {time.perf_counter() - started:.1f}秒）")  # 全体の所要時間を表示する
    return 0                                                 # 成功（0）で終了する


if __name__ == "__main__":                                   # このファイルを直接実行したときだけ、下を動かす（他から読み込まれたときは動かさない）
    sys.exit(main())                                         # main() を実行し、その結果（0か1）を終了コードにして終わる
