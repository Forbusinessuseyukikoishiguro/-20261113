import { defineConfig } from 'vitest/config';

export default defineConfig({
  test: {
    // E2E（Playwright）は Vitest の対象外
    include: ['tests/unit/**/*.test.js', 'tests/dom/**/*.test.js'],
    // 日付・タイムゾーンの影響を受けないことを確認するため、環境側のタイムゾーンは固定しない（章4で解説）
    reporters: ['default'],
  },
});
