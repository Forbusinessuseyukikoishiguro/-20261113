#!/usr/bin/env python3
"""pytest-json-report / Jest(--json) / Vitest(--reporter=json) / Playwright(--reporter=json) の出力を、共通スキーマ(results.normalized.json)に正規化する。

使い方:
  python normalize_results.py results.json --env local-win11 --out results.normalized.json
  オプション: --framework auto|pytest|jest|playwright  --label Vitest  --commit <hash>  --run-id <id>  --max-log 500

共通スキーマ:
  {run_id, env, commit, framework, executed_at, summary{total,pass,fail,skip},
   tests:[{id, name, result(PASS/FAIL/SKIP), duration_ms, error}]}
"""
import argparse
import json
import re
import subprocess
import sys
from datetime import datetime, timezone

ANSI = re.compile(r"\x1b\[[0-9;]*[A-Za-z]")

MASKS = [
    (re.compile(r"(?:[A-Za-z]:[\\/]Users[\\/]|/home/|/Users/)[^\\/\s]+"), "[HOME]"),
    (re.compile(r"[\w.+-]+@[\w-]+\.[\w.-]+"), "[EMAIL]"),
    (re.compile(r"(?i)bearer\s+[A-Za-z0-9._\-]+"), "Bearer [TOKEN]"),
    (re.compile(r"\b(?:secret|ntn|sk|ghp|xox[bp])[_-][A-Za-z0-9_\-]{8,}"), "[TOKEN]"),
    (re.compile(r"(?i)(password|passwd|token|api[_-]?key)\s*[=:]\s*\S+"), r"\1=[MASKED]"),
]


def mask(text, max_len):
    if not text:
        return None
    text = ANSI.sub("", text)
    for pat, rep in MASKS:
        text = pat.sub(rep, text)
    text = text.strip()
    return text[:max_len] + ("…" if len(text) > max_len else "")


def to_result(status):
    s = (status or "").lower()
    if s in ("passed", "xpassed"):
        return "PASS"
    if s in ("failed", "error"):
        return "FAIL"
    return "SKIP"  # skipped / pending / todo / xfailed / その他


def from_pytest(data, max_log):
    tests = []
    for t in data.get("tests", []):
        stages = [t.get(k) or {} for k in ("setup", "call", "teardown")]
        dur = sum((st.get("duration") or 0) for st in stages)
        res = to_result(t.get("outcome"))
        err = None
        if res == "FAIL":
            for st in stages:
                if st.get("outcome") == "failed":
                    crash = st.get("crash") or {}
                    err = st.get("longrepr") or crash.get("message")
                    break
        nodeid = t.get("nodeid", "")
        tests.append({
            "id": nodeid,
            "name": nodeid.split("::")[-1],
            "result": res,
            "duration_ms": int(round(dur * 1000)),
            "error": mask(err, max_log),
        })
    return tests


def from_jest(data, max_log):
    tests = []
    for f in data.get("testResults", []):
        fname = (f.get("name") or "").replace("\\", "/").split("/")[-1]
        asserts = f.get("assertionResults", [])
        if not asserts and f.get("status") == "failed":  # テストファイル自体の失敗
            tests.append({"id": fname, "name": fname, "result": "FAIL", "duration_ms": 0,
                          "error": mask(f.get("message"), max_log)})
        for a in asserts:
            res = to_result(a.get("status"))
            full = a.get("fullName") or a.get("title") or ""
            tests.append({
                "id": f"{fname}::{full}",
                "name": a.get("title") or full,
                "result": res,
                "duration_ms": int(round(a.get("duration") or 0)),
                "error": mask("\n".join(a.get("failureMessages") or []), max_log) if res == "FAIL" else None,
            })
    return tests


def from_playwright(data, max_log):
    """Playwright の JSON レポーター（suites > specs > tests > results）を平坦化する。"""
    tests = []

    def walk(suite, titles):
        for spec in suite.get("specs", []):
            for t in spec.get("tests", []):
                results = t.get("results") or []
                status = t.get("status")  # expected / unexpected / flaky / skipped
                res = {"expected": "PASS", "flaky": "PASS", "unexpected": "FAIL", "skipped": "SKIP"}.get(status, "SKIP")
                dur = sum((r.get("duration") or 0) for r in results)
                err = None
                if res == "FAIL" and results:
                    e = (results[-1].get("error") or {})
                    err = e.get("message") or ""
                name = " > ".join(titles + [spec.get("title", "")])
                proj = t.get("projectName") or ""
                tests.append({
                    "id": f"{spec.get('file', suite.get('file', ''))}::{name}" + (f" [{proj}]" if proj else ""),
                    "name": spec.get("title", ""),
                    "result": res,
                    "duration_ms": int(round(dur)),
                    "error": mask(err, max_log),
                })
        for child in suite.get("suites", []):
            # ファイルを表すトップの suite は title がファイル名なので、タイトル階層には含めない
            sub = titles if child.get("title") == child.get("file") else titles + [child.get("title", "")]
            walk(child, sub)

    for top in data.get("suites", []):
        walk(top, [] if top.get("title") == top.get("file") else [top.get("title", "")])
    return tests


def detect(data):
    if "testResults" in data:
        return "jest"  # Vitest の JSON レポーターも同じ形式
    if "suites" in data and "config" in data:
        return "playwright"
    if "tests" in data and ("summary" in data or "created" in data):
        return "pytest"
    raise SystemExit("形式を判別できません。--framework で pytest / jest / playwright を指定してください。")


def git_commit():
    try:
        return subprocess.check_output(["git", "rev-parse", "--short", "HEAD"], stderr=subprocess.DEVNULL, text=True).strip()
    except Exception:
        return "unknown"


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("input")
    ap.add_argument("--framework", default="auto", choices=["auto", "pytest", "jest", "playwright"])
    ap.add_argument("--env", default="local-" + sys.platform)
    ap.add_argument("--commit", default=None)
    ap.add_argument("--run-id", default=None)
    ap.add_argument("--label", default=None, help="Notionのフレームワーク欄に入れる名前（例：Vitest）。未指定なら pytest/jest/playwright")
    ap.add_argument("--max-log", type=int, default=500)
    ap.add_argument("--out", default="results.normalized.json")
    a = ap.parse_args()

    with open(a.input, encoding="utf-8") as fh:
        data = json.load(fh)
    fw = detect(data) if a.framework == "auto" else a.framework
    converter = {"pytest": from_pytest, "jest": from_jest, "playwright": from_playwright}[fw]
    tests = converter(data, a.max_log)

    now = datetime.now(timezone.utc)
    commit = a.commit or git_commit()
    run_id = a.run_id or f"{now:%Y%m%d-%H%M}-{commit[:7]}"
    count = lambda r: sum(1 for t in tests if t["result"] == r)
    out = {
        "run_id": run_id, "env": a.env, "commit": commit, "framework": a.label or fw,
        "executed_at": now.isoformat(timespec="seconds"),
        "summary": {"total": len(tests), "pass": count("PASS"), "fail": count("FAIL"), "skip": count("SKIP")},
        "tests": tests,
    }
    with open(a.out, "w", encoding="utf-8") as fh:
        json.dump(out, fh, ensure_ascii=False, indent=2)
    s = out["summary"]
    print(f"{fw}: total={s['total']} PASS={s['pass']} FAIL={s['fail']} SKIP={s['skip']} -> {a.out}")


if __name__ == "__main__":
    main()
