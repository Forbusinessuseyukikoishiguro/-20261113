import { describe, it, expect } from 'vitest';
import { filterRecords, calcKpi, groupByMonth, groupByDept, sortRecords, growthRate } from '../../js/metrics.js';

// テストデータは「小さく・意図が読める」固定値にする（章4）
const rec = (date, dept, amount, quantity = 1, product = 'P') => ({ date, dept, product, amount, quantity });
const DATA = [
  rec('2026-01-31', 'EC', 4200, 4),
  rec('2026-02-01', '営業', 100000),
  rec('2026-02-14', 'EC', 14700, 3),
  rec('2026-02-28', '店舗', 10000, 2),
  rec('2026-03-01', 'EC', 5000),
];

describe('filterRecords', () => {
  it('条件なしなら全件', () => {
    expect(filterRecords(DATA)).toHaveLength(5);
  });
  it('期間は両端を含む（境界値）', () => {
    const r = filterRecords(DATA, { from: '2026-02-01', to: '2026-02-28' });
    expect(r.map((x) => x.date)).toEqual(['2026-02-01', '2026-02-14', '2026-02-28']);
  });
  it('開始日の前日・終了日の翌日は含まない', () => {
    const r = filterRecords(DATA, { from: '2026-02-02', to: '2026-02-27' });
    expect(r.map((x) => x.date)).toEqual(['2026-02-14']);
  });
  it('部門で絞れる。all や空文字は絞らない', () => {
    expect(filterRecords(DATA, { dept: 'EC' })).toHaveLength(3);
    expect(filterRecords(DATA, { dept: 'all' })).toHaveLength(5);
    expect(filterRecords(DATA, { dept: '' })).toHaveLength(5);
  });
  it('期間と部門は AND 条件', () => {
    expect(filterRecords(DATA, { from: '2026-02-01', to: '2026-02-28', dept: 'EC' })).toHaveLength(1);
  });
  it('元の配列を変更しない', () => {
    const copy = structuredClone(DATA);
    filterRecords(DATA, { dept: 'EC' });
    expect(DATA).toEqual(copy);
  });
});

describe('calcKpi', () => {
  it('売上・件数・数量・平均単価を計算する', () => {
    expect(calcKpi([rec('2026-01-01', 'EC', 100, 2), rec('2026-01-02', 'EC', 300, 3)])).toEqual({
      revenue: 400, orders: 2, units: 5, avgOrder: 200,
    });
  });
  it('0件のとき平均単価は null（0 と区別する）', () => {
    expect(calcKpi([])).toEqual({ revenue: 0, orders: 0, units: 0, avgOrder: null });
  });
  it('割り切れない平均はそのまま返す（丸めは表示側の責任）', () => {
    expect(calcKpi([rec('2026-01-01', 'EC', 100), rec('2026-01-02', 'EC', 101), rec('2026-01-03', 'EC', 101)]).avgOrder).toBeCloseTo(100.6667, 4);
  });
});

describe('groupByMonth', () => {
  it('月ごとに合計し、昇順に並べる', () => {
    expect(groupByMonth(DATA)).toEqual([
      { month: '2026-01', revenue: 4200 },
      { month: '2026-02', revenue: 124700 },
      { month: '2026-03', revenue: 5000 },
    ]);
  });
  it('月末・月初の境界日が正しい月に入る（タイムゾーン非依存）', () => {
    const r = groupByMonth([rec('2026-01-31', 'EC', 1), rec('2026-02-01', 'EC', 2)]);
    expect(r).toEqual([{ month: '2026-01', revenue: 1 }, { month: '2026-02', revenue: 2 }]);
  });
  it('空配列は空', () => {
    expect(groupByMonth([])).toEqual([]);
  });
});

describe('groupByDept', () => {
  it('売上の多い順に並べる', () => {
    expect(groupByDept(DATA).map((d) => d.dept)).toEqual(['営業', 'EC', '店舗']);
  });
  it('同額のときは部門名の昇順で順序が固定される', () => {
    const r = groupByDept([rec('2026-01-01', 'B', 10), rec('2026-01-01', 'A', 10)]);
    expect(r.map((d) => d.dept)).toEqual(['A', 'B']);
  });
});

describe('sortRecords', () => {
  it('数値は数値として比較する（100 より 20 が小さい）', () => {
    const r = sortRecords([rec('2026-01-01', 'A', 100), rec('2026-01-02', 'A', 20)], 'amount', 'asc');
    expect(r.map((x) => x.amount)).toEqual([20, 100]);
  });
  it('降順にできる', () => {
    expect(sortRecords(DATA, 'amount', 'desc')[0].amount).toBe(100000);
  });
  it('同じ値の行は元の順序を保つ（安定ソート）', () => {
    const r = sortRecords([rec('2026-01-01', 'A', 5, 1, 'first'), rec('2026-01-02', 'A', 5, 1, 'second')], 'amount', 'desc');
    expect(r.map((x) => x.product)).toEqual(['first', 'second']);
  });
  it('元の配列を変更しない', () => {
    const before = DATA.map((x) => x.date);
    sortRecords(DATA, 'amount', 'desc');
    expect(DATA.map((x) => x.date)).toEqual(before);
  });
});

describe('growthRate', () => {
  it('増減率を返す', () => {
    expect(growthRate(120, 100)).toBeCloseTo(0.2);
    expect(growthRate(80, 100)).toBeCloseTo(-0.2);
  });
  it('前期が 0 のときは null', () => {
    expect(growthRate(100, 0)).toBeNull();
  });
  it('数値でないときは null', () => {
    expect(growthRate(NaN, 100)).toBeNull();
  });
});
