import { describe, it, expect } from 'vitest';
import { isValidDate, parseCsvLines, parseSalesCsv } from '../../js/data.js';

describe('isValidDate', () => {
  it.each([['2026-02-28', true], ['2026-02-30', false], ['2024-02-29', true], ['2026-13-01', false], ['2026-2-3', false], ['', false]])(
    '%s -> %s',
    (input, expected) => expect(isValidDate(input)).toBe(expected),
  );
});

describe('parseCsvLines', () => {
  it('カンマ入りの引用符付きフィールドを1つの値として扱う', () => {
    expect(parseCsvLines('a,b\n"x,y",z')).toEqual([['a', 'b'], ['x,y', 'z']]);
  });
  it('CRLF と BOM を扱える', () => {
    expect(parseCsvLines('\uFEFFa,b\r\n1,2\r\n')).toEqual([['a', 'b'], ['1', '2']]);
  });
  it('空行は無視する', () => {
    expect(parseCsvLines('a\n\n\nb')).toEqual([['a'], ['b']]);
  });
});

const HEADER = 'date,dept,product,amount,quantity\n';

describe('parseSalesCsv', () => {
  it('正しい行を数値に変換して返す', () => {
    const { records, errors } = parseSalesCsv(`${HEADER}2026-01-05,営業,保守契約A,120000,1\n`);
    expect(errors).toEqual([]);
    expect(records).toEqual([{ date: '2026-01-05', dept: '営業', product: '保守契約A', amount: 120000, quantity: 1 }]);
  });
  it('不正な行は records に入れず、行番号つきで errors に積む', () => {
    const { records, errors } = parseSalesCsv(`${HEADER}2026-02-30,EC,x,abc,1\n2026-02-03,営業,y,100,1\n`);
    expect(records).toHaveLength(1);
    expect(errors).toHaveLength(1);
    expect(errors[0].line).toBe(2);
  });
  it('金額が空欄の行も不正として扱う（Number("") は 0 になる罠）', () => {
    const { records, errors } = parseSalesCsv(`${HEADER}2026-02-03,営業,y,,1\n`);
    expect(records).toEqual([]);
    expect(errors[0].reason).toContain('金額');
  });
  it('必須列が無いときは全体を読み込まずエラーにする', () => {
    const { records, errors } = parseSalesCsv('date,dept\n2026-01-01,営業\n');
    expect(records).toEqual([]);
    expect(errors[0].reason).toContain('必須列');
  });
  it('空文字は空の結果', () => {
    expect(parseSalesCsv('')).toEqual({ records: [], errors: [] });
  });
});
