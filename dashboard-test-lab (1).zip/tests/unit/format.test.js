import { describe, it, expect } from 'vitest';
import { formatYen, formatPercent, formatDate } from '../../js/format.js';

describe('formatYen', () => {
  it('3桁区切りで ¥ を付ける', () => {
    expect(formatYen(993300)).toBe('¥993,300');
  });
  it('0 は ¥0', () => {
    expect(formatYen(0)).toBe('¥0');
  });
  it('小数は四捨五入する（66220.5 -> ¥66,221）', () => {
    expect(formatYen(66220.5)).toBe('¥66,221');
  });
  it('負の値は - を先頭に付ける', () => {
    expect(formatYen(-1500)).toBe('-¥1,500');
  });
  it.each([[NaN], [Infinity], [null], [undefined], ['100']])('数値でない値（%s）は — にする', (v) => {
    expect(formatYen(v)).toBe('—');
  });
});

describe('formatPercent', () => {
  it('小数1桁の % にする', () => {
    expect(formatPercent(0.1234)).toBe('12.3%');
  });
  it('負の値も扱える', () => {
    expect(formatPercent(-0.05)).toBe('-5.0%');
  });
  it('数値でないときは —', () => {
    expect(formatPercent(null)).toBe('—');
  });
});

describe('formatDate', () => {
  it('YYYY-MM-DD を YYYY/MM/DD にする', () => {
    expect(formatDate('2026-02-03')).toBe('2026/02/03');
  });
  it('形式が違うときは空文字', () => {
    expect(formatDate('2026/02/03')).toBe('');
    expect(formatDate(undefined)).toBe('');
  });
});
