import { test, expect } from '@playwright/test';
import AxeBuilder from '@axe-core/playwright';

// 小さな固定データ（API モック用）。本物の CSV に依存しないテストにする
const MOCK_CSV = [
  'date,dept,product,amount,quantity',
  '2026-04-01,営業,テストA,1000,1',
  '2026-04-02,EC,テストB,3000,2',
].join('\n');

test.describe('実データでの動作', () => {
  test.beforeEach(async ({ page }) => {
    await page.goto('/');
    // 初期表示の完了を「状態」で待つ（固定の sleep は使わない）
    await expect(page.getByTestId('row')).toHaveCount(15);
  });

  test('初期表示：KPIが集計値になり、不正行の警告が出る', async ({ page }) => {
    await expect(page.getByTestId('kpi-revenue')).toHaveText('¥993,300');
    await expect(page.getByTestId('kpi-orders')).toHaveText('15件');
    await expect(page.getByTestId('kpi-avg')).toHaveText('¥66,220');
    await expect(page.getByTestId('load-warning')).toContainText('1件');
  });

  test('部門を EC に絞ると KPI と明細が変わる', async ({ page }) => {
    await page.getByTestId('filter-dept').selectOption('EC');
    await expect(page.getByTestId('kpi-revenue')).toHaveText('¥42,000');
    await expect(page.getByTestId('row')).toHaveCount(5);
  });

  test('期間（2月）× EC で 1件・¥14,700', async ({ page }) => {
    await page.getByTestId('filter-from').fill('2026-02-01');
    await page.getByTestId('filter-to').fill('2026-02-28');
    await page.getByTestId('filter-dept').selectOption('EC');
    await expect(page.getByTestId('kpi-revenue')).toHaveText('¥14,700');
    await expect(page.getByTestId('row')).toHaveCount(1);
  });

  test('該当なしの期間では空状態を表示する', async ({ page }) => {
    await page.getByTestId('filter-from').fill('2027-01-01');
    await expect(page.getByTestId('empty-state')).toHaveText('該当するデータがありません');
    await expect(page.getByTestId('kpi-avg')).toHaveText('—');
  });

  test('金額の見出しをクリックすると降順に並ぶ（2回クリック）', async ({ page }) => {
    const header = page.getByRole('button', { name: '金額' });
    await header.click();
    await header.click();
    await expect(page.getByTestId('row').first().locator('td').nth(3)).toHaveText('¥250,000');
    await expect(page.getByRole('columnheader', { name: '金額' })).toHaveAttribute('aria-sort', 'descending');
  });

  test('グラフ（SVG）の棒の値を DOM から検証できる', async ({ page }) => {
    const bars = page.getByTestId('bar');
    await expect(bars).toHaveCount(3);
    await expect(bars.nth(1)).toHaveAttribute('data-value', '401000');
    await expect(bars.nth(1)).toHaveAttribute('aria-label', '2026-02 ¥401,000');
  });
});

test.describe('データ取得のモック（章7）', () => {
  test('CSV をモックに差し替えて、小さな固定データで検証する', async ({ page }) => {
    await page.route('**/data/sales.csv', (route) => route.fulfill({ status: 200, contentType: 'text/csv', body: MOCK_CSV }));
    await page.goto('/');
    await expect(page.getByTestId('kpi-revenue')).toHaveText('¥4,000');
    await expect(page.getByTestId('kpi-orders')).toHaveText('2件');
  });

  test('サーバーエラー(500)のときはエラーバナーを表示する', async ({ page }) => {
    await page.route('**/data/sales.csv', (route) => route.fulfill({ status: 500, body: 'error' }));
    await page.goto('/');
    await expect(page.getByTestId('error-banner')).toBeVisible();
    await expect(page.getByTestId('error-banner')).toContainText('500');
  });

  test('ネットワーク切断のときもエラーバナーを表示する', async ({ page }) => {
    await page.route('**/data/sales.csv', (route) => route.abort('failed'));
    await page.goto('/');
    await expect(page.getByTestId('error-banner')).toBeVisible();
  });
});

test.describe('レスポンシブ・アクセシビリティ・見た目（章8）', () => {
  test('スマホ幅でもページが横にはみ出さない', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 700 });
    await page.goto('/');
    await expect(page.getByTestId('row')).toHaveCount(15);
    const overflow = await page.evaluate(() => document.documentElement.scrollWidth - window.innerWidth);
    expect(overflow).toBeLessThanOrEqual(0);
  });

  test('アクセシビリティ違反（axe）がない', async ({ page }) => {
    await page.goto('/');
    await expect(page.getByTestId('row')).toHaveCount(15);
    const results = await new AxeBuilder({ page }).analyze();
    expect(results.violations, results.violations.map((v) => `${v.id}: ${v.help}`).join('\n')).toEqual([]);
  });

  test('ビジュアル回帰：ダッシュボード全体のスクリーンショット', async ({ page }) => {
    await page.goto('/');
    await expect(page.getByTestId('row')).toHaveCount(15);
    // 日付や乱数のような「毎回変わる部分」は無いが、あればここで mask する
    await expect(page).toHaveScreenshot('dashboard.png', { fullPage: true, maxDiffPixelRatio: 0.01 });
  });
});
