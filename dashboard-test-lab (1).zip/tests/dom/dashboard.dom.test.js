// @vitest-environment jsdom
import { describe, it, expect, beforeEach } from 'vitest';
import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { within, fireEvent } from '@testing-library/dom';
import userEvent from '@testing-library/user-event';
import { initDashboard } from '../../js/app.js';

// jsdom 環境では import.meta.url が file: にならないため、プロジェクト直下からの相対パスで読む
const HTML = readFileSync(join(process.cwd(), 'index.html'), 'utf-8');
const CSV = readFileSync(join(process.cwd(), 'data/sales.csv'), 'utf-8');

// index.html の <body> の中身だけを使い、<script> は実行しない（fetch を差し替えたいので）
const bodyHtml = (HTML.match(/<body>([\s\S]*)<\/body>/)[1]).replace(/<script[\s\S]*?<\/script>/g, '');

const okFetch = (text) => async () => ({ ok: true, status: 200, text: async () => text });
const tid = (id) => document.querySelector(`[data-testid="${id}"]`);
const rows = () => [...document.querySelectorAll('[data-testid="row"]')];
const col = (i) => rows().map((tr) => tr.children[i].textContent);

beforeEach(() => {
  document.body.innerHTML = bodyHtml;
});

describe('初期表示', () => {
  beforeEach(async () => { await initDashboard({ document, fetchFn: okFetch(CSV) }); });

  it('KPIが全件の集計値になる', () => {
    expect(tid('kpi-revenue').textContent).toBe('¥993,300');
    expect(tid('kpi-orders').textContent).toBe('15件');
    expect(tid('kpi-avg').textContent).toBe('¥66,220');
    expect(tid('kpi-units').textContent).toBe('36個');
  });

  it('明細は不正行を除いた15行', () => {
    expect(rows()).toHaveLength(15);
  });

  it('グラフは3か月分の棒で、値が DOM から検証できる', () => {
    const bars = [...document.querySelectorAll('[data-testid="bar"]')];
    expect(bars.map((b) => [b.dataset.label, b.dataset.value])).toEqual([
      ['2026-01', '229000'], ['2026-02', '401000'], ['2026-03', '363300'],
    ]);
  });

  it('不正な行があることを警告で知らせる', () => {
    expect(tid('load-warning').hidden).toBe(false);
    expect(tid('load-warning').textContent).toContain('1件');
  });

  it('部門の選択肢が CSV から作られる', () => {
    const options = [...tid('filter-dept').querySelectorAll('option')].map((o) => o.value);
    expect(options).toEqual(['all', 'EC', '営業', '店舗']);
  });
});

describe('フィルタ操作', () => {
  it('部門を EC にすると KPI・明細・グラフが更新される', async () => {
    await initDashboard({ document, fetchFn: okFetch(CSV) });
    const user = userEvent.setup();
    await user.selectOptions(tid('filter-dept'), 'EC');
    expect(tid('kpi-revenue').textContent).toBe('¥42,000');
    expect(tid('kpi-orders').textContent).toBe('5件');
    expect(rows()).toHaveLength(5);
    expect(document.querySelectorAll('[data-testid="bar"]')).toHaveLength(3);
  });

  it('2月だけの期間 + EC で 1件・¥14,700', async () => {
    await initDashboard({ document, fetchFn: okFetch(CSV) });
    const user = userEvent.setup();
    fireEvent.change(tid('filter-from'), { target: { value: '2026-02-01' } });
    fireEvent.change(tid('filter-to'), { target: { value: '2026-02-28' } });
    await user.selectOptions(tid('filter-dept'), 'EC');
    expect(tid('kpi-revenue').textContent).toBe('¥14,700');
    expect(rows()).toHaveLength(1);
  });

  it('該当データが無いときは空状態を表示し、平均単価は — になる', async () => {
    await initDashboard({ document, fetchFn: okFetch(CSV) });
    fireEvent.change(tid('filter-from'), { target: { value: '2027-01-01' } });
    expect(tid('empty-state').textContent).toBe('該当するデータがありません');
    expect(tid('kpi-avg').textContent).toBe('—');
    expect(tid('kpi-orders').textContent).toBe('0件');
  });
});

describe('並べ替え', () => {
  it('金額の見出しを1回押すと昇順、もう1回で降順', async () => {
    await initDashboard({ document, fetchFn: okFetch(CSV) });
    const user = userEvent.setup();
    const btn = within(document.querySelector('thead')).getByRole('button', { name: '金額' });
    await user.click(btn);
    expect(col(3)[0]).toBe('¥4,200');
    expect(btn.closest('th').getAttribute('aria-sort')).toBe('ascending');
    await user.click(btn);
    expect(col(3)[0]).toBe('¥250,000');
    expect(btn.closest('th').getAttribute('aria-sort')).toBe('descending');
  });

  it('別の見出しに切り替えると、それ以外の aria-sort は none に戻る', async () => {
    await initDashboard({ document, fetchFn: okFetch(CSV) });
    const user = userEvent.setup();
    const thead = within(document.querySelector('thead'));
    await user.click(thead.getByRole('button', { name: '金額' }));
    await user.click(thead.getByRole('button', { name: '部門' }));
    expect(thead.getByRole('button', { name: '金額' }).closest('th').getAttribute('aria-sort')).toBe('none');
  });
});

describe('異常系', () => {
  it('HTTP エラーのときはエラーバナーを出し、画面は壊れない', async () => {
    const failing = async () => ({ ok: false, status: 500, text: async () => '' });
    await initDashboard({ document, fetchFn: failing });
    expect(tid('error-banner').hidden).toBe(false);
    expect(tid('error-banner').textContent).toContain('500');
  });

  it('通信自体が失敗（例外）したときもエラーバナーを出す', async () => {
    const boom = async () => { throw new Error('network down'); };
    await initDashboard({ document, fetchFn: boom });
    expect(tid('error-banner').textContent).toContain('network down');
  });

  it('ヘッダーだけの CSV でも例外にならず、空状態になる', async () => {
    await initDashboard({ document, fetchFn: okFetch('date,dept,product,amount,quantity\n') });
    expect(tid('empty-state')).not.toBeNull();
  });
});
