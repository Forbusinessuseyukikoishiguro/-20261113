// 表示用の整形関数（純粋関数：同じ入力なら必ず同じ出力）

/** 金額を ¥1,234 形式にする。数値でなければ「—」 */
export function formatYen(n) {
  if (typeof n !== 'number' || !Number.isFinite(n)) return '—';
  const sign = n < 0 ? '-' : '';
  const body = Math.round(Math.abs(n)).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
  return `${sign}¥${body}`;
}

/** 0.1234 -> 12.3%（小数1桁）。数値でなければ「—」 */
export function formatPercent(ratio, digits = 1) {
  if (typeof ratio !== 'number' || !Number.isFinite(ratio)) return '—';
  return `${(ratio * 100).toFixed(digits)}%`;
}

/** 2026-02-03 -> 2026/02/03。タイムゾーンの影響を避けるため Date を使わず文字列で処理する */
export function formatDate(iso) {
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(iso ?? '');
  return m ? `${m[1]}/${m[2]}/${m[3]}` : '';
}
