// 集計ロジック（純粋関数）。DOM には一切触れない＝テストしやすい

/** 期間（両端を含む）と部門で絞り込む。dept が空 / 'all' なら部門で絞らない */
export function filterRecords(records, { from = '', to = '', dept = 'all' } = {}) {
  return records.filter((r) => {
    if (from && r.date < from) return false;
    if (to && r.date > to) return false;
    if (dept && dept !== 'all' && r.dept !== dept) return false;
    return true;
  });
}

/** KPI：売上合計・件数・平均単価・数量合計。0 件のときの平均単価は null（0 と区別する） */
export function calcKpi(records) {
  const revenue = records.reduce((s, r) => s + r.amount, 0);
  const orders = records.length;
  const units = records.reduce((s, r) => s + r.quantity, 0);
  return { revenue, orders, units, avgOrder: orders === 0 ? null : revenue / orders };
}

/** 月別売上（昇順）。月は日付文字列の先頭7文字で判定する */
export function groupByMonth(records) {
  const map = new Map();
  for (const r of records) {
    const month = r.date.slice(0, 7);
    map.set(month, (map.get(month) ?? 0) + r.amount);
  }
  return [...map.entries()].sort(([a], [b]) => a.localeCompare(b)).map(([month, revenue]) => ({ month, revenue }));
}

/** 部門別売上（売上の多い順。同額は部門名の昇順で順序を固定する） */
export function groupByDept(records) {
  const map = new Map();
  for (const r of records) map.set(r.dept, (map.get(r.dept) ?? 0) + r.amount);
  return [...map.entries()]
    .map(([dept, revenue]) => ({ dept, revenue }))
    .sort((a, b) => b.revenue - a.revenue || a.dept.localeCompare(b.dept));
}

/** 並べ替え（元の配列は変更しない）。同じ値は元の順序を保つ */
export function sortRecords(records, key, dir = 'asc') {
  const sign = dir === 'desc' ? -1 : 1;
  return records
    .map((r, i) => [r, i])
    .sort(([a, ia], [b, ib]) => {
      const va = a[key];
      const vb = b[key];
      const cmp = typeof va === 'number' && typeof vb === 'number' ? va - vb : String(va).localeCompare(String(vb), 'ja');
      return cmp * sign || ia - ib;
    })
    .map(([r]) => r);
}

/** 増減率。前期が 0 のときは計算できないので null */
export function growthRate(current, previous) {
  if (!Number.isFinite(current) || !Number.isFinite(previous) || previous === 0) return null;
  return (current - previous) / previous;
}
