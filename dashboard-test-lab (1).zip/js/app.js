// 画面の組み立て。依存（document・fetch）を引数で受け取ることで、テストから差し替えられる
import { parseSalesCsv } from './data.js';
import { filterRecords, calcKpi, groupByMonth, sortRecords } from './metrics.js';
import { renderKpis, renderTable, renderChart } from './render.js';

export async function initDashboard({ document, fetchFn = globalThis.fetch, csvUrl = 'data/sales.csv' } = {}) {
  const $ = (id) => document.querySelector(`[data-testid="${id}"]`);
  const banner = $('error-banner');
  const warning = $('load-warning');

  let records = [];
  try {
    const res = await fetchFn(csvUrl);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const parsed = parseSalesCsv(await res.text());
    records = parsed.records;
    if (parsed.errors.length) {
      warning.hidden = false;
      warning.textContent = `読み込めなかった行：${parsed.errors.length}件`;
      warning.title = parsed.errors.map((e) => `${e.line}行目 ${e.reason}`).join('\n');
    }
  } catch (e) {
    banner.hidden = false;
    banner.textContent = `データを読み込めませんでした（${e.message}）`;
    return { state: { records: [] } };
  }

  const deptSelect = $('filter-dept');
  [...new Set(records.map((r) => r.dept))].sort((a, b) => a.localeCompare(b, 'ja')).forEach((d) => {
    const opt = document.createElement('option');
    opt.value = d;
    opt.textContent = d;
    deptSelect.append(opt);
  });

  const state = { records, filter: { from: '', to: '', dept: 'all' }, sort: { key: 'date', dir: 'asc' } };

  function update() {
    const filtered = filterRecords(state.records, state.filter);
    renderKpis(document, calcKpi(filtered));
    renderChart($('chart-container'), groupByMonth(filtered));
    renderTable($('table-body'), sortRecords(filtered, state.sort.key, state.sort.dir));
    document.querySelectorAll('[data-sort]').forEach((btn) => {
      const th = btn.closest('th');
      th.setAttribute('aria-sort', btn.dataset.sort === state.sort.key ? (state.sort.dir === 'asc' ? 'ascending' : 'descending') : 'none');
    });
  }

  $('filter-from').addEventListener('change', (e) => { state.filter.from = e.target.value; update(); });
  $('filter-to').addEventListener('change', (e) => { state.filter.to = e.target.value; update(); });
  deptSelect.addEventListener('change', (e) => { state.filter.dept = e.target.value; update(); });
  document.querySelectorAll('[data-sort]').forEach((btn) => btn.addEventListener('click', () => {
    const key = btn.dataset.sort;
    state.sort = { key, dir: state.sort.key === key && state.sort.dir === 'asc' ? 'desc' : 'asc' };
    update();
  }));

  update();
  return { state };
}
