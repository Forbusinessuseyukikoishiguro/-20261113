// 描画（DOM を書き換える）。計算は metrics.js に任せ、ここは「表示」だけを担当する
import { formatYen, formatDate } from './format.js';

const SVG_NS = 'http://www.w3.org/2000/svg';

export function renderKpis(root, kpi) {
  const set = (id, text) => { root.querySelector(`[data-testid="${id}"]`).textContent = text; };
  set('kpi-revenue', formatYen(kpi.revenue));
  set('kpi-orders', `${kpi.orders}件`);
  set('kpi-avg', kpi.avgOrder === null ? '—' : formatYen(kpi.avgOrder));
  set('kpi-units', `${kpi.units}個`);
}

export function renderTable(tbody, rows) {
  const doc = tbody.ownerDocument;
  tbody.replaceChildren();
  if (rows.length === 0) {
    const tr = doc.createElement('tr');
    const td = doc.createElement('td');
    td.colSpan = 5;
    td.dataset.testid = 'empty-state';
    td.textContent = '該当するデータがありません';
    tr.append(td);
    tbody.append(tr);
    return;
  }
  for (const r of rows) {
    const tr = doc.createElement('tr');
    tr.dataset.testid = 'row';
    const cells = [formatDate(r.date), r.dept, r.product, formatYen(r.amount), String(r.quantity)];
    cells.forEach((text, i) => {
      const td = doc.createElement('td');
      td.textContent = text;
      if (i >= 3) td.className = 'num';
      tr.append(td);
    });
    tbody.append(tr);
  }
}

/** 月別売上の棒グラフ（SVG）。canvas と違い、DOM から値を検証できる（data-value / aria-label） */
export function renderChart(container, series) {
  const doc = container.ownerDocument;
  container.replaceChildren();
  const W = 480, H = 220, pad = 32;
  const svg = doc.createElementNS(SVG_NS, 'svg');
  svg.setAttribute('viewBox', `0 0 ${W} ${H}`);
  svg.setAttribute('role', 'group'); // 棒の1本ずつに role="img" と aria-label を付けるため、全体は group にする（axe の指摘で修正）
  svg.setAttribute('aria-label', '月別売上の棒グラフ');
  svg.dataset.testid = 'chart';
  const max = Math.max(1, ...series.map((s) => s.revenue));
  const bw = series.length ? (W - pad * 2) / series.length : 0;
  series.forEach((s, i) => {
    const h = Math.round(((H - pad * 2) * s.revenue) / max);
    const x = pad + i * bw + bw * 0.15;
    const rect = doc.createElementNS(SVG_NS, 'rect');
    rect.setAttribute('x', String(x));
    rect.setAttribute('y', String(H - pad - h));
    rect.setAttribute('width', String(bw * 0.7));
    rect.setAttribute('height', String(h));
    rect.setAttribute('class', 'bar');
    rect.setAttribute('role', 'img');
    rect.dataset.testid = 'bar';
    rect.dataset.label = s.month;
    rect.dataset.value = String(s.revenue);
    rect.setAttribute('aria-label', `${s.month} ${formatYen(s.revenue)}`);
    svg.append(rect);
    const label = doc.createElementNS(SVG_NS, 'text');
    label.setAttribute('x', String(x + (bw * 0.7) / 2));
    label.setAttribute('y', String(H - pad + 16));
    label.setAttribute('text-anchor', 'middle');
    label.textContent = s.month.slice(5) + '月';
    svg.append(label);
  });
  container.append(svg);
}
