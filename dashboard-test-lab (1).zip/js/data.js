// CSV の読み込みと検証（純粋関数）

/** 実在する日付か（2026-02-30 のような日付を弾く）。Date は UTC で扱い、実行環境のタイムゾーンに依存しない */
export function isValidDate(iso) {
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(iso ?? '');
  if (!m) return false;
  const [y, mo, d] = [Number(m[1]), Number(m[2]), Number(m[3])];
  const dt = new Date(Date.UTC(y, mo - 1, d));
  return dt.getUTCFullYear() === y && dt.getUTCMonth() === mo - 1 && dt.getUTCDate() === d;
}

/** 引用符付きフィールド（"a,b"）と CRLF、BOM に対応した簡易 CSV パーサー。行ごとの配列を返す */
export function parseCsvLines(text) {
  const src = String(text ?? '').replace(/^\uFEFF/, '');
  const rows = [];
  let row = [];
  let field = '';
  let inQuotes = false;
  for (let i = 0; i < src.length; i++) {
    const c = src[i];
    if (inQuotes) {
      if (c === '"' && src[i + 1] === '"') { field += '"'; i++; }
      else if (c === '"') inQuotes = false;
      else field += c;
    } else if (c === '"') inQuotes = true;
    else if (c === ',') { row.push(field); field = ''; }
    else if (c === '\n' || c === '\r') {
      if (c === '\r' && src[i + 1] === '\n') i++;
      row.push(field); field = '';
      if (row.some((v) => v !== '')) rows.push(row);
      row = [];
    } else field += c;
  }
  row.push(field);
  if (row.some((v) => v !== '')) rows.push(row);
  return rows;
}

/**
 * 売上 CSV を { records, errors } に変換する。
 * 不正な行は records に入れず errors に「行番号と理由」を積む（ダッシュボードを止めない）。
 */
export function parseSalesCsv(text) {
  const lines = parseCsvLines(text);
  const records = [];
  const errors = [];
  if (lines.length === 0) return { records, errors };
  const header = lines[0].map((h) => h.trim());
  const idx = Object.fromEntries(['date', 'dept', 'product', 'amount', 'quantity'].map((k) => [k, header.indexOf(k)]));
  const missing = Object.entries(idx).filter(([, i]) => i < 0).map(([k]) => k);
  if (missing.length) {
    errors.push({ line: 1, reason: `必須列がありません: ${missing.join(', ')}` });
    return { records, errors };
  }
  lines.slice(1).forEach((cols, i) => {
    const line = i + 2;
    const get = (k) => (cols[idx[k]] ?? '').trim();
    const amount = Number(get('amount'));
    const quantity = Number(get('quantity'));
    if (!isValidDate(get('date'))) return errors.push({ line, reason: `日付が不正です: ${get('date')}` });
    if (get('amount') === '' || !Number.isFinite(amount)) return errors.push({ line, reason: `金額が数値ではありません: ${get('amount')}` });
    if (get('quantity') === '' || !Number.isFinite(quantity)) return errors.push({ line, reason: `数量が数値ではありません: ${get('quantity')}` });
    records.push({ date: get('date'), dept: get('dept'), product: get('product'), amount, quantity });
  });
  return { records, errors };
}
