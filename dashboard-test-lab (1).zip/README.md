# dashboard-test-lab

Udemy講座「実務で使える！HTML/CSS/JSダッシュボードのテスト自動化」の演習リポジトリです（うさうさ研修工房）。

ビルド不要の素の HTML / CSS / JS で作った「売上KPIダッシュボード」と、その **テスト一式**（ユニット・DOM・E2E・アクセシビリティ・ビジュアル回帰・CI）が入っています。

## 題材アプリ

CSV（`data/sales.csv`）を読み込み、期間・部門で絞り込んで、KPIカード・月別グラフ（SVG）・明細テーブル（並べ替え可）を表示します。

- CSV には **わざと不正な行を1行** 入れています（存在しない日付 `2026-02-30`・金額 `abc`）。ダッシュボードは止まらず、「読み込めなかった行：1件」と警告します。
- 正しい行は 15 件。期待値は **売上合計 ¥993,300 / 件数 15 / 平均単価 ¥66,220 / 数量 36**（Python で独立に計算して確認済み）。

## はじめかた（Windows / PowerShell）

```powershell
npm install
npx playwright install chromium    # E2E 用ブラウザ（初回のみ）
npm run serve                      # http://localhost:4173 で画面を確認
```

| コマンド | 内容 | 章 |
|---|---|---|
| `npm run test:unit` | ユニットテスト（Vitest）49件 | 5 |
| `npm run test:dom` | DOMテスト（Vitest + jsdom + Testing Library）13件 | 6 |
| `npm run test:tz` | タイムゾーンを変えてユニットテストを実行 | 4 |
| `npm run test:e2e` | E2E・アクセシビリティ・ビジュアル回帰（Playwright）12件 | 7・8 |
| `npm test` | ユニット＋DOM | |
| `npm run test:all` | すべて | |
| `npm run test:json` | Vitest の結果を JSON で出力（Notion 記録用） | 付録 |

### ビジュアル回帰の初回について

基準画像は OS・ブラウザごとに作られるため、リポジトリには含めていません。

1. 初回の `npm run test:e2e` は、基準画像を書き出して **ビジュアル回帰の1件が失敗** します（正常な動作です）。
2. もう一度実行すると、基準画像と比較して通ります。
3. 画面を意図的に変えたら `npx playwright test --update-snapshots` で基準画像を更新します。
4. CI（Linux）用の基準画像は、CI 上で作ったものをコミットします（Windows の画像は使えません）。

## 構成

```
index.html            画面（data-testid を付けて、テストから探しやすくしてある）
css/style.css
js/
  format.js           金額・日付の整形（純粋関数）
  data.js             CSV の読み込みと検証（純粋関数）
  metrics.js          絞り込み・集計・並べ替え（純粋関数）
  render.js           DOM / SVG の描画
  app.js              画面の組み立て（document と fetch を引数で受け取る＝テストで差し替え可能）
data/sales.csv
tests/
  unit/               format / data / metrics
  dom/                フィルタ・並べ替え・異常系（jsdom）
  e2e/                Playwright（実ブラウザ）
tools/normalize_results.py   テスト結果を共通JSONにそろえる（Notion 記録用）
.github/workflows/test.yml   CI（GitHub Actions）
docs/pitfalls.md      実務の落とし穴
```

### 何をどの層で守るか（章1）

| 壊れ方 | 守る層 | 例 |
|---|---|---|
| 数字（集計・丸め・境界日） | ユニット | 期間の両端を含む、0件の平均は null |
| 表示（整形・空状態） | ユニット・DOM | `¥993,300`、「該当するデータがありません」 |
| 操作（フィルタ・並べ替え） | DOM・E2E | 部門を EC にすると ¥42,000 |
| 通信・異常系 | DOM・E2E | 500エラー、ネットワーク切断、不正行 |
| 見た目・使いやすさ | E2E | スマホ幅で横にはみ出さない、axe、スクリーンショット |

## 壊してみる演習（テストは本当に守っているか？）

講座の山場です。次のようにわざとバグを入れて、テストが失敗するかを確認します。作成者の環境では、すべて失敗（＝検出）することを確認済みです。

| # | 壊し方 | 失敗するテスト |
|---|---|---|
| 1 | `metrics.js` の `r.date > to` を `r.date >= to` にする（終了日を含めない） | 期間の境界値テスト |
| 2 | `calcKpi` の `avgOrder` を 0件のとき `0` にする | ユニット＋DOM（空状態の平均単価） |
| 3 | `groupByMonth` を `new Date(r.date)` とローカル時間で月を取る | `npm run test:tz`（米国時間でだけ失敗）。日本時間で通っても安心できない例 |
| 4 | `data.js` の空欄金額チェックを外す | 空欄金額のテスト（`Number('')` は 0 になる罠） |
| 5 | `render.js` の件数表示を `orders + 1` にする | DOM・E2E の両方 |

## Notion に結果を記録する（付録・前の講座と接続）

テスト結果の JSON は、同梱の変換ツールで共通形式にそろえ、Claude Code の Notion MCP と `notion-test-recorder` スキルで Notion の DB に記録できます。

```powershell
npm run test:json                                  # results.vitest.json（Vitest）
npx playwright test                                # results.json（Playwright。設定済み）

python tools/normalize_results.py results.vitest.json --label Vitest --env local-win11 --out vitest.normalized.json
python tools/normalize_results.py results.json --label Playwright --env local-win11 --out e2e.normalized.json
```

Notion の「フレームワーク」列には Vitest / Playwright の選択肢を追加しておきます。

## 動作確認の環境

Node.js 22 / Vitest 5.1 / jsdom 31 / Playwright 1.65 / @axe-core/playwright 4.14（Linux で全テスト実行・通過を確認）。

- **Windows での実行と GitHub Actions の実行は未確認**です。講座の収録前に、ご自身の環境で `npm install` から一通り実行してください。
- ツールのバージョンアップで挙動や出力形式が変わることがあります。`package-lock.json` を同梱しているので、まずは `npm ci` で同じバージョンを再現してください。
